<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Islamabad Capital Territory Police | Official Website</title>
    <meta name="description" content="ICT Police – Online/Walk-in Services, Locate PS/PKM Near Me, Apps, Divisions, Initiatives. Emergency: 15 | Safe City Coverage 90%">

    <!-- Libraries -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Almarai:wght@400;700&family=Cormorant+Garamond:ital,wght@0,500;0,600;1,600&family=Inter:wght@400;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    
    <style>
        :root { --primary: #003087; --gold: #D4AF37; --dark: #0f172a; --light: #f8f9fa; --white: #ffffff; }
        body { font-family: 'Inter', sans-serif; line-height: 1.6; }
        .top-bar { padding: 0; font-size: 0.88rem; }
        .navbar { background: var(--primary); box-shadow: 0 4px 20px rgba(0,0,0,0.1); transition: all 0.3s; color: #fff; }
        .navbar.sticky { position: fixed; top: 0; width: 100%; z-index: 1000; }
        .navbar .nav-link { transition: color 0.3s; color: #fff; }
        .navbar .nav-link:hover { color: var(--gold) !important; }
        .dropdown-menu { animation: fadeIn 0.3s ease-in-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .hero-slider .swiper-slide { height: 100%; position: relative; }
        .hero-slider video, .hero-slider img { width: 100%; height: 100%; object-fit: cover; filter: brightness(0.8); transition: filter 0.5s; }
        .hero-slider .swiper-slide:hover video, .hero-slider .swiper-slide:hover img { filter: brightness(1); }
        .hero-overlay { position: absolute; inset: 0; background: rgba(0,0,0,0.6); z-index: 1; transition: background 0.5s; }
        .stat-card { background: var(--light); border-radius: 15px; padding: 30px; transition: all 0.3s; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .stat-card:hover { transform: scale(1.05); box-shadow: 0 10px 25px rgba(0,0,0,0.2); }
        .stat-icon { font-size: 3rem; color: var(--primary); }
        .service-card { transition: all 0.3s ease; box-shadow: 0 5px 15px rgba(0,0,0,0.1); border: none; animation: cardPulse 2s infinite alternate; }
        @keyframes cardPulse { 0% { transform: scale(1); } 100% { transform: scale(1.02); } }
        .service-card:hover { transform: translateY(-10px) scale(1.05); box-shadow: 0 15px 30px rgba(0,0,0,0.2); animation: none; }
        .map-container { height: 500px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); animation: mapGlow 3s infinite alternate; }
        @keyframes mapGlow { 0% { box-shadow: 0 5px 20px rgba(0,0,0,0.1); } 100% { box-shadow: 0 5px 30px rgba(0,0,0,0.2); } }
        .search-input { border: 2px solid var(--primary); border-radius: 30px; padding: 12px 25px; font-size: 1.1rem; transition: border-color 0.3s; }
        .search-input:focus { border-color: var(--gold); }
        .social-icons a { width: 50px; height: 50px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin: 0 8px; transition: all 0.3s; box-shadow: 0 5px 15px rgba(0,0,0,0.2); animation: socialBounce 1.5s infinite; }
        @keyframes socialBounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
        .social-icons a:hover { animation: none; transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.3); }
        .emergency-chat-container { position: fixed; bottom: 30px; right: 30px; z-index: 9999; }
        .main-float-btn { width: 60px; height: 60px; border-radius: 50%; background: var(--primary); color: white; font-size: 1.5rem; box-shadow: 0 5px 15px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.3s; }
        .main-float-btn:hover { background: var(--gold); }
        .sub-btn { width: 50px; height: 50px; border-radius: 50%; color: white; font-size: 1.2rem; box-shadow: 0 5px 15px rgba(0,0,0,0.2); display: flex; align-items: center; justify-content: center; text-decoration: none; position: absolute; right: 5px; transition: all 0.3s; opacity: 0; visibility: hidden; }
        .sub-btn.emergency { background: #dc3545; top: -60px; }
        .sub-btn.chat { background: #28a745; top: -120px; }
        .emergency-chat-container.open .sub-btn { opacity: 1; visibility: visible; top: auto; animation: slideDown 0.3s ease-out; }
        @keyframes slideDown { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .left-helplines { position: fixed; bottom: 30px; left: 30px; z-index: 9999; }
        .helpline-main { width: 60px; height: 60px; border-radius: 50%; background: var(--primary); color: white; font-size: 1.5rem; box-shadow: 0 5px 15px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.3s; }
        .helpline-main:hover { background: var(--gold); }
        .helpline-sub { width: 50px; height: 50px; border-radius: 50%; color: white; font-size: 1.2rem; box-shadow: 0 5px 15px rgba(0,0,0,0.2); display: flex; align-items: center; justify-content: center; text-decoration: none; position: absolute; left: 5px; transition: all 0.3s; opacity: 0; visibility: hidden; }
        .helpline-sub.women { background: #ff69b4; top: -60px; }
        .helpline-sub.igp { background: #28a745; top: -120px; }
        .helpline-sub.itp { background: #007bff; top: -180px; }
        .left-helplines.open .helpline-sub { opacity: 1; visibility: visible; top: auto; animation: slideDown 0.3s ease-out; }
        footer { background: var(--dark); color: white; padding: 50px 0; }
        .footer-link { color: #ccc; transition: color 0.3s; }
        .footer-link:hover { color: var(--gold); }
        .footer-section { border-right: 1px solid #333; }
        .footer-section:last-child { border-right: none; }
        .section-online { background: #e3f2fd; } /* Light blue for online */
        .section-apps { background: #e8f5e9; } /* Light green for apps */
        .section-walkin { background: #fff3e0; } /* Light orange for walk-in */
        .section-divisions { background: #f3e5f5; } /* Light purple for divisions */
        .section-locator { background: #e0f7fa; } /* Light cyan for locator */
        .section-media { background: #fce4ec; } /* Light pink for media */
    </style>
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/homepage-responsive.css">

</head>
<body>
<div class="helplines-sidebar" id="helplinesSidebar" aria-label="Emergency helplines">
    <a href="tel:15" class="helpline-btn pucar" data-helpline>
        <i class="fas fa-phone-volume" aria-hidden="true"></i>
        <span>Emergency 15</span>
    </a>
    <a href="tel:1815" class="helpline-btn women" data-helpline>
        <i class="fas fa-female" aria-hidden="true"></i>
        <span>Online Women PS 1815</span>
    </a>
    <a href="tel:1715" class="helpline-btn igp" data-helpline>
        <i class="fas fa-shield" aria-hidden="true"></i>
        <span>IGP Complaint Cell 1715</span>
    </a>
    <a href="tel:1915" class="helpline-btn itp" data-helpline>
        <i class="fas fa-car" aria-hidden="true"></i>
        <span>Traffic Helpline 1915</span>
    </a>
</div>

<style>
.helplines-sidebar {
    position: fixed;
    top: 50%;
    left: 0;
    transform: translateY(-50%);
    display: flex;
    flex-direction: column;
    gap: 6px;
    z-index: 9998;
    padding: 8px 0;
    max-width: calc(100vw - 12px);
}

.helpline-btn {
    display: flex;
    align-items: center;
    width: 42px;
    height: 42px;
    background: #003087;
    color: #fff;
    font-size: 1rem;
    text-decoration: none;
    transition: width 0.28s ease, background 0.28s ease, box-shadow 0.28s ease;
    overflow: hidden;
    white-space: nowrap;
    border-top-right-radius: 21px;
    border-bottom-right-radius: 21px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.22);
    -webkit-tap-highlight-color: transparent;
    touch-action: manipulation;
}

.helpline-btn i {
    flex: 0 0 42px;
    width: 42px;
    text-align: center;
    line-height: 42px;
}

.helpline-btn span {
    opacity: 0;
    max-width: 0;
    overflow: hidden;
    transition: opacity 0.22s ease, max-width 0.28s ease;
    padding-right: 0;
    font-weight: 600;
    font-size: 0.88rem;
}

.helpline-btn.is-expanded,
.helplines-sidebar.has-expanded .helpline-btn.is-expanded {
    width: min(248px, calc(100vw - 20px));
    box-shadow: 0 4px 14px rgba(0, 0, 0, 0.28);
}

.helpline-btn.is-expanded span,
.helplines-sidebar.has-expanded .helpline-btn.is-expanded span {
    opacity: 1;
    max-width: 200px;
    padding-right: 14px;
}

@media (hover: hover) and (pointer: fine) {
    .helpline-btn:hover {
        width: min(248px, calc(100vw - 20px));
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.28);
    }

    .helpline-btn:hover span {
        opacity: 1;
        max-width: 200px;
        padding-right: 14px;
    }
}

.pucar { background: #bb333b; }
.pucar:hover,
.pucar.is-expanded { background: #c93d45; }
.women { background: #ff69b4; }
.women:hover,
.women.is-expanded { background: #ff4d9f; }
.igp { background: #28a745; }
.igp:hover,
.igp.is-expanded { background: #218838; }
.itp { background: #007bff; }
.itp:hover,
.itp.is-expanded { background: #0069d9; }

@media (max-width: 575.98px) {
    .helplines-sidebar {
        top: 50%;
        left: 0;
        bottom: auto;
        right: auto;
        transform: translateY(-50%);
    }

    .helpline-btn {
        width: 40px;
        height: 40px;
    }

    .helpline-btn i {
        flex: 0 0 40px;
        width: 40px;
        line-height: 40px;
        font-size: 0.95rem;
    }

    .helpline-btn.is-expanded,
    .helplines-sidebar.has-expanded .helpline-btn.is-expanded {
        width: min(260px, calc(100vw - 16px));
    }

    .helpline-btn span {
        font-size: 0.82rem;
    }
}
</style>

<script>
(function () {
    var sidebar = document.getElementById('helplinesSidebar');
    if (!sidebar) return;

    var buttons = sidebar.querySelectorAll('[data-helpline]');

    function needsTwoTap() {
        return window.matchMedia('(hover: none), (pointer: coarse)').matches;
    }

    function collapseAll() {
        buttons.forEach(function (btn) {
            btn.classList.remove('is-expanded');
            btn.removeAttribute('data-expanded');
        });
        sidebar.classList.remove('has-expanded');
    }

    buttons.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            if (!needsTwoTap()) {
                return;
            }

            if (btn.getAttribute('data-expanded') === '1') {
                collapseAll();
                return;
            }

            e.preventDefault();
            e.stopPropagation();

            buttons.forEach(function (other) {
                if (other !== btn) {
                    other.classList.remove('is-expanded');
                    other.removeAttribute('data-expanded');
                }
            });

            btn.classList.add('is-expanded');
            btn.setAttribute('data-expanded', '1');
            sidebar.classList.add('has-expanded');
        });
    });

    document.addEventListener('click', function (e) {
        if (!sidebar.classList.contains('has-expanded')) {
            return;
        }
        if (sidebar.contains(e.target)) {
            return;
        }
        collapseAll();
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            collapseAll();
        }
    });

    window.addEventListener('resize', function () {
        if (!needsTwoTap()) {
            collapseAll();
        }
    });
})();
</script>
<style>
.top-bar {
    position: relative;
    background: linear-gradient(105deg, #001f5c 0%, #003087 42%, #004aad 100%);
    border-bottom: 3px solid #D4AF37;
    animation: fadeIn 0.5s ease-in;
    padding: 0.55rem 0;
    overflow: hidden;
}
.top-bar::before {
    content: '';
    position: absolute;
    inset: 0;
    background: radial-gradient(circle at 50% 120%, rgba(212, 175, 55, 0.16) 0%, transparent 58%);
    pointer-events: none;
}
.top-bar-inner {
    position: relative;
    z-index: 1;
}
.top-bar-grid {
    display: grid;
    grid-template-columns: auto 1fr auto;
    align-items: center;
    gap: 1rem;
}
.top-bar-logo {
    display: flex;
    align-items: center;
    justify-self: start;
}
.top-bar-logo a {
    display: inline-flex;
    line-height: 0;
}
.top-bar-logo a:hover .logo-img {
    transform: scale(1.02);
}
.top-bar-center {
    text-align: center;
    justify-self: center;
    width: 100%;
    max-width: 640px;
    margin: 0 auto;
}
.top-bar-tagline {
    line-height: 1.3;
}
.top-bar-dept {
    display: block;
    font-family: 'Playfair Display', Georgia, 'Times New Roman', serif;
    font-size: clamp(0.75rem, 1.65vw, 1.01rem);
    font-weight: 700;
    color: #fff;
    letter-spacing: 0.03em;
    line-height: 1.25;
    text-transform: uppercase;
    text-shadow: 0 2px 12px rgba(0, 0, 0, 0.2);
}
.top-bar-motto {
    display: block;
    font-family: 'Cormorant Garamond', Georgia, serif;
    font-size: clamp(0.79rem, 1.8vw, 1.09rem);
    font-weight: 600;
    font-style: italic;
    color: #f3dfa0;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    margin-top: 0.15rem;
    text-shadow: 0 1px 8px rgba(0, 0, 0, 0.18);
}
.top-bar-motto::before,
.top-bar-motto::after {
    content: '—';
    color: rgba(212, 175, 55, 0.75);
    margin: 0 0.45rem;
    font-style: normal;
    font-weight: 500;
}
.top-bar-helplines {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    justify-self: end;
}
.logo-img {
    height: 72px;
    width: auto;
    filter: drop-shadow(0 3px 10px rgba(0, 0, 0, 0.28));
    transition: transform 0.3s ease;
}
.helpline-chip.emergency {
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    padding: 0.48rem 1rem;
    border-radius: 999px;
    font-family: 'Inter', sans-serif;
    font-size: 0.88rem;
    font-weight: 700;
    text-decoration: none;
    color: #fff;
    background: linear-gradient(135deg, #dc2626, #b91c1c);
    border: 1px solid rgba(255, 255, 255, 0.35);
    box-shadow: 0 4px 14px rgba(220, 38, 38, 0.35);
    animation: emergencyPulse 2s infinite;
    white-space: nowrap;
    transition: transform 0.25s ease, background 0.25s ease;
}
.helpline-chip.emergency i {
    font-size: 0.9rem;
}
.helpline-chip.emergency span.num {
    color: #fff7d6;
    font-weight: 800;
    letter-spacing: 0.05em;
}
.helpline-chip.emergency:hover {
    transform: translateY(-2px);
    background: linear-gradient(135deg, #ef4444, #dc2626);
    color: #fff;
}
@keyframes emergencyPulse {
    0% { box-shadow: 0 4px 14px rgba(220, 38, 38, 0.35), 0 0 0 0 rgba(220, 38, 38, 0.5); }
    70% { box-shadow: 0 4px 14px rgba(220, 38, 38, 0.35), 0 0 0 8px rgba(220, 38, 38, 0); }
    100% { box-shadow: 0 4px 14px rgba(220, 38, 38, 0.35), 0 0 0 0 rgba(220, 38, 38, 0); }
}
@media (max-width: 991.98px) {
    .top-bar-grid {
        grid-template-columns: auto 1fr;
        grid-template-areas:
            "logo emergency"
            "center center";
        gap: 0.65rem 1rem;
    }
    .top-bar-logo { grid-area: logo; }
    .top-bar-center { grid-area: center; }
    .top-bar-helplines {
        grid-area: emergency;
        justify-content: flex-end;
    }
}
@media (max-width: 575.98px) {
    .logo-img {
        height: 54px;
    }
    .top-bar-motto {
        letter-spacing: 0.06em;
    }
    .top-bar-motto::before,
    .top-bar-motto::after {
        margin: 0 0.3rem;
    }
}
</style>

<div class="top-bar">
    <div class="container top-bar-inner py-2">
        <div class="top-bar-grid">
            <div class="top-bar-logo">
                <a href="index.php">
                    <img src="assets/images/Capital_Territory_Police.png" alt="ICT Police" class="logo-img">
                </a>
            </div>

            <div class="top-bar-center">
                <div class="top-bar-tagline">
                    <span class="top-bar-dept">Islamabad Capital Territory Police</span>
                    <span class="top-bar-motto">Service With Passion</span>
                </div>
            </div>

            <div class="top-bar-helplines">
                                <a href="tel:15" class="helpline-chip emergency">
                    <i class="fas fa-phone-volume"></i>
                    <span>Emergency</span>
                    <span class="num">15</span>
                </a>
            </div>
        </div>
    </div>
</div>
<!-- Sticky Navbar -->
<style>
.navbar {
    background: #0c315d;
    border-bottom: 1px solid #fff;
    border-top: 1px solid #fff;
}
.navbar-nav .nav-link {
    color: #fff !important;
    font-weight: 500;
    transition: all 0.3s ease;
}
.navbar-nav .nav-link:hover {
    color: #D4AF37 !important;
}
.dropdown-menu {
    background: #1e3a8a;
    border: none;
    border-radius: 8px;
}
.dropdown-item {
    color: #fff !important;
    font-weight: 400;
}
.dropdown-item:hover {
    background: #D4AF37;
    color: #000 !important;
}
</style>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMain">
            <ul class="navbar-nav w-100 d-flex flex-lg-row justify-content-lg-around fw-semibold">
                                <li class="nav-item ">
                    <a class="nav-link " 
                       href="index.php" 
                       >
                                                    <i class="fas fa-home me-2"></i>
                                                Home                    </a>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="#" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-shield me-2"></i>
                                                About Us                    </a>
                                        <ul class="dropdown-menu">
                                                                        <li>
                            <a class="dropdown-item" href="about.php">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                About ICTP                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="vision.php">
                                                                    <i class="fas fa-receipt me-2"></i>
                                                                Our Vision &amp; Mission                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="igp-message.php">
                                                                    <i class="fas fa-id-card me-2"></i>
                                                                IGP Message                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="officers.php">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Officers of Islamabad Police                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="organ.php">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Organogram                            </a>
                        </li>
                                                                    </ul>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="#" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-laptop me-2"></i>
                                                Services                    </a>
                                        <ul class="dropdown-menu">
                                                                            <li>
                            <a class="dropdown-item" href="https://soft.islamabadpolice.gov.pk/appointment/" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-book me-2"></i>
                                                                Book Online Appointment                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-cc.php">
                                                                    <i class="fas fa-id-card me-2"></i>
                                                                Character Certificate                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-gv.php">
                                                                    <i class="fas fa-check me-2"></i>
                                                                General Police Verification                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-tr.php">
                                                                    <i class="fas fa-home me-2"></i>
                                                                Tenant Registration                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-sr.php">
                                                                    <i class="fas fa-user me-2"></i>
                                                                Servant Registration                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-fr.php">
                                                                    <i class="fas fa-globe me-2"></i>
                                                                Foreigner Registration                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://dlims.islamabadpolice.gov.pk/" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-id-card-alt me-2"></i>
                                                                Driving License Renewal                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://dlims.islamabadpolice.gov.pk/" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-id-card-alt me-2"></i>
                                                                Online Learner Permit                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://traffic.islamabadpolice.gov.pk/Echallan" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-receipt me-2"></i>
                                                                E-Challan Verification                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://dlims.islamabadpolice.gov.pk/" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-id-card-alt me-2"></i>
                                                                Driving License Verification                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-fir.php">
                                                                    <i class="fas fa-copy me-2"></i>
                                                                Copy of FIR                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-lr.php">
                                                                    <i class="fas fa-file-alt me-2"></i>
                                                                Lost Report                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://islamabadpolice.gov.pk/fms/complaints.php" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-comment-dots me-2"></i>
                                                                Report an Incident                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://islamabadpolice.gov.pk/fms/" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-book me-2"></i>
                                                                Give Feedback                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="facilitation-on-wheels.php">
                                                                    <i class="fas fa-bus me-2"></i>
                                                                Facilitation On Wheels                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://soft.islamabadpolice.gov.pk/tvs/login" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-car me-2"></i>
                                                                Taxi Verification System                            </a>
                        </li>
                                                                        </ul>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="heros.php" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-medal me-2"></i>
                                                Our Heroes                    </a>
                                        <ul class="dropdown-menu">
                                                                        <li>
                            <a class="dropdown-item" href="heros.php">
                                                                    <i class="fas fa-moon me-2"></i>
                                                                Our Martyrs                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="ghazis.php">
                                                                    <i class="fas fa-medal me-2"></i>
                                                                Our Ghazis                            </a>
                        </li>
                                                                    </ul>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="#" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-lightbulb me-2"></i>
                                                Initiatives                    </a>
                                        <ul class="dropdown-menu">
                                                                        <li>
                            <a class="dropdown-item" href="initiatives.php?slug=-nline-omen-olice-tation">
                                                                Online Women Police Station                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="initiatives.php?slug=-acilitation-on-wheels">
                                                                Facilitation On Wheels                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="initiatives.php?slug=-olice-tation-n-heels">
                                                                Police Station (PS) On Wheels                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="initiatives.php?slug=-mergency-elplines">
                                                                Emergency Helplines                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="initiatives.php?slug=-ssential-afety-ips-for-itizens">
                                                                Essential Safety Tips for Citizens                            </a>
                        </li>
                                                                    </ul>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="#" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-building me-2"></i>
                                                Divisions                    </a>
                                        <ul class="dropdown-menu">
                                                                        <li>
                            <a class="dropdown-item" href="division.php?slug=safe-city-islamabad">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Safe City Islamabad                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=operations-division">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Operations Division                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=law-order-and-training-division">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Law &amp; Order and Training Division                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=security-division">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Security Division                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=headquarters-logistics-division">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Headquarters &amp; Logistics Division                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=islamabad-traffic-police">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Islamabad Traffic Police (ITP)                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=ctd">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Counter Terrorism Department (CTD)                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=special-branch">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Special Branch Islamabad Police                            </a>
                        </li>
                                                                    </ul>
                                    </li>
                                <li class="nav-item ">
                    <a class="nav-link " 
                       href="media.php" 
                       >
                                                    <i class="fas fa-hands-helping me-2"></i>
                                                Media                    </a>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="#" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-bullhorn me-2"></i>
                                                Notices                    </a>
                                        <ul class="dropdown-menu">
                                                                        <li>
                            <a class="dropdown-item" href="tender.php">
                                                                    <i class="fas fa-file-contract me-2"></i>
                                                                Tender                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="auction.php">
                                                                    <i class="fas fa-gavel me-2"></i>
                                                                Auctions                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="job.php">
                                                                    <i class="fas fa-briefcase me-2"></i>
                                                                Jobs                            </a>
                        </li>
                                                                    </ul>
                                    </li>
                                <li class="nav-item ">
                    <a class="nav-link " 
                       href="contact.php" 
                       >
                                                    <i class="fas fa-envelope me-2"></i>
                                                Contact                    </a>
                                    </li>
                            </ul>
        </div>
    </div>
</nav>

<style>
.contact-page {
    --navy: #0a2a52;
    --blue: #0e4a8c;
    --gold: #c9a227;
    --gold-soft: #f3e6b8;
    --muted: #64748b;
    --line: #e2e8f0;
    --surface: #f5f8fc;
}
.contact-hero {
    position: relative;
    color: #fff;
    overflow: hidden;
    background: linear-gradient(115deg, #081c37 0%, #0e4a8c 52%, #0a2a52 100%);
    border-bottom: 4px solid var(--gold);
}
.contact-hero::before {
    content: '';
    position: absolute;
    inset: 0;
    background:
        radial-gradient(circle at 15% 20%, rgba(201, 162, 39, 0.18), transparent 28%),
        radial-gradient(circle at 90% 80%, rgba(255, 255, 255, 0.07), transparent 30%);
    pointer-events: none;
}
.contact-hero-inner {
    position: relative;
    z-index: 1;
    padding: 3.4rem 0 2.8rem;
}
.contact-kicker {
    display: inline-block;
    font-size: 0.75rem;
    letter-spacing: 0.16em;
    text-transform: uppercase;
    font-weight: 700;
    color: var(--gold-soft);
    margin-bottom: 0.65rem;
}
.contact-hero h1 {
    margin: 0 0 0.65rem;
    font-size: clamp(2rem, 4vw, 2.9rem);
    font-weight: 800;
    letter-spacing: -0.02em;
}
.contact-hero p {
    margin: 0;
    max-width: 40rem;
    font-size: 1.08rem;
    opacity: 0.92;
    line-height: 1.6;
}
.contact-breadcrumb {
    background: #fff;
    border-bottom: 1px solid var(--line);
    padding: 0.7rem 0;
    font-size: 0.9rem;
}
.contact-breadcrumb a {
    color: var(--blue);
    text-decoration: none;
    font-weight: 600;
}
.contact-breadcrumb a:hover { color: var(--gold); }
.contact-breadcrumb .sep { color: #94a3b8; margin: 0 0.5rem; }

.contact-section {
    padding: 2.75rem 0;
}
.contact-section.surface { background: var(--surface); }
.contact-section.white { background: #fff; }

.contact-section-head {
    margin-bottom: 1.6rem;
}
.contact-section-head h2 {
    margin: 0 0 0.35rem;
    font-size: clamp(1.4rem, 2.4vw, 1.8rem);
    font-weight: 800;
    color: var(--navy);
}
.contact-section-head p {
    margin: 0;
    color: var(--muted);
}

.helpline-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1rem;
}
.helpline-card {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 0.7rem;
    padding: 1.35rem 1.2rem;
    border-radius: 18px;
    background: #fff;
    border: 1px solid #e8eef6;
    box-shadow: 0 12px 28px rgba(10, 42, 82, 0.07);
    text-decoration: none;
    color: inherit;
    transition: transform 0.25s ease, box-shadow 0.25s ease, border-color 0.25s ease;
    height: 100%;
}
.helpline-card:hover {
    transform: translateY(-5px);
    border-color: rgba(201, 162, 39, 0.45);
    box-shadow: 0 18px 38px rgba(10, 42, 82, 0.12);
    color: inherit;
}
.helpline-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(145deg, rgba(201, 162, 39, 0.2), rgba(10, 42, 82, 0.08));
    color: var(--navy);
    font-size: 1.15rem;
}
.helpline-card .label {
    font-size: 0.88rem;
    font-weight: 650;
    color: var(--muted);
    margin: 0;
}
.helpline-card .number {
    margin: 0;
    font-size: 1.65rem;
    font-weight: 800;
    color: var(--navy);
    letter-spacing: -0.02em;
    line-height: 1.1;
}
.helpline-card .cta {
    margin-top: auto;
    font-size: 0.82rem;
    font-weight: 700;
    color: #b8860b;
}

.info-panel {
    background: #fff;
    border-radius: 22px;
    border: 1px solid rgba(10, 42, 82, 0.07);
    box-shadow: 0 16px 40px rgba(10, 42, 82, 0.07);
    overflow: hidden;
}
.info-panel-head {
    padding: 1.15rem 1.4rem;
    background: linear-gradient(135deg, var(--navy), #134a8c);
    color: #fff;
}
.info-panel-head h3 {
    margin: 0;
    font-size: 1.1rem;
    font-weight: 750;
}
.info-list {
    list-style: none;
    margin: 0;
    padding: 0.35rem 0;
}
.info-list li {
    display: flex;
    gap: 1rem;
    align-items: flex-start;
    padding: 1.1rem 1.4rem;
    border-bottom: 1px solid #eef2f7;
}
.info-list li:last-child { border-bottom: none; }
.info-list .ico {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: rgba(201, 162, 39, 0.14);
    color: var(--navy);
}
.info-list .title {
    margin: 0 0 0.2rem;
    font-size: 0.82rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: var(--muted);
}
.info-list .value {
    margin: 0;
    color: #1e293b;
    font-size: 1.02rem;
    line-height: 1.55;
    font-weight: 600;
}
.info-list a.value {
    color: var(--blue);
    text-decoration: none;
}
.info-list a.value:hover { color: var(--gold); }

.social-row {
    display: flex;
    flex-wrap: wrap;
    gap: 0.75rem;
}
.social-chip {
    display: inline-flex;
    align-items: center;
    gap: 0.55rem;
    padding: 0.7rem 1rem;
    border-radius: 999px;
    background: #fff;
    border: 1px solid #e8eef6;
    color: var(--navy);
    text-decoration: none;
    font-weight: 700;
    font-size: 0.92rem;
    box-shadow: 0 8px 18px rgba(10, 42, 82, 0.05);
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
}
.social-chip:hover {
    transform: translateY(-2px);
    background: var(--navy);
    color: #fff;
    box-shadow: 0 12px 24px rgba(10, 42, 82, 0.15);
}
.social-chip i { width: 18px; text-align: center; }

.loc-toolbar {
    display: flex;
    flex-wrap: wrap;
    gap: 0.85rem;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1.25rem;
}
.loc-tabs {
    display: inline-flex;
    flex-wrap: wrap;
    gap: 0.45rem;
    padding: 0.35rem;
    background: #eef2f7;
    border-radius: 14px;
}
.loc-tab {
    border: 0;
    background: transparent;
    color: #475569;
    font-weight: 700;
    font-size: 0.9rem;
    padding: 0.55rem 0.95rem;
    border-radius: 10px;
    cursor: pointer;
    transition: background 0.2s ease, color 0.2s ease;
}
.loc-tab.active {
    background: var(--navy);
    color: #fff;
    box-shadow: 0 8px 18px rgba(10, 42, 82, 0.2);
}
.loc-tab .count {
    display: inline-block;
    margin-left: 0.35rem;
    padding: 0.05rem 0.45rem;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.18);
    font-size: 0.75rem;
}
.loc-tab:not(.active) .count {
    background: rgba(10, 42, 82, 0.08);
}
.loc-search {
    position: relative;
    min-width: min(100%, 280px);
}
.loc-search input {
    width: 100%;
    border: 1px solid #dbe3ef;
    border-radius: 12px;
    padding: 0.7rem 1rem 0.7rem 2.5rem;
    font-size: 0.95rem;
    outline: none;
    background: #fff;
}
.loc-search input:focus {
    border-color: #93b4df;
    box-shadow: 0 0 0 3px rgba(14, 74, 140, 0.12);
}
.loc-search i {
    position: absolute;
    left: 0.9rem;
    top: 50%;
    transform: translateY(-50%);
    color: #94a3b8;
}
.loc-panel { display: none; }
.loc-panel.active { display: block; }
.loc-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
}
.loc-card {
    background: #fff;
    border: 1px solid #e8eef6;
    border-radius: 16px;
    padding: 1.15rem 1.15rem 1.2rem;
    box-shadow: 0 10px 24px rgba(10, 42, 82, 0.05);
    height: 100%;
    display: flex;
    flex-direction: column;
    gap: 0.45rem;
    transition: transform 0.22s ease, box-shadow 0.22s ease;
}
.loc-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 16px 34px rgba(10, 42, 82, 0.1);
}
.loc-card h4 {
    margin: 0;
    font-size: 1.02rem;
    font-weight: 750;
    color: var(--navy);
    line-height: 1.3;
}
.loc-meta {
    margin: 0;
    font-size: 0.88rem;
    color: var(--muted);
    line-height: 1.5;
}
.loc-meta i {
    width: 16px;
    color: var(--gold);
    margin-right: 0.3rem;
}
.loc-phone {
    margin-top: auto;
    padding-top: 0.55rem;
    font-weight: 700;
    color: #0f766e;
    text-decoration: none;
    font-size: 0.92rem;
}
.loc-phone:hover { color: var(--navy); }
.loc-empty {
    display: none;
    text-align: center;
    padding: 2.5rem 1rem;
    color: var(--muted);
    border: 1px dashed var(--line);
    border-radius: 16px;
    background: #fff;
}
.loc-empty.show { display: block; }
.loc-map-cta {
    margin-top: 1.5rem;
    text-align: center;
}
.loc-map-cta a {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.8rem 1.35rem;
    border-radius: 999px;
    background: linear-gradient(135deg, var(--navy), #165499);
    color: #fff;
    text-decoration: none;
    font-weight: 700;
    box-shadow: 0 12px 28px rgba(10, 42, 82, 0.2);
}
.loc-map-cta a:hover { color: #fff; filter: brightness(1.05); }

@media (max-width: 991.98px) {
    .helpline-grid { grid-template-columns: repeat(2, 1fr); }
    .loc-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 575.98px) {
    .helpline-grid,
    .loc-grid { grid-template-columns: 1fr; }
    .contact-hero-inner { padding: 2.5rem 0 2rem; }
    .loc-toolbar { align-items: stretch; }
    .loc-search { min-width: 100%; }
}
</style>

<div class="contact-page">
    <section class="contact-hero">
        <div class="container contact-hero-inner">
            <div class="contact-kicker">Islamabad Capital Territory Police</div>
            <h1>Contact Us</h1>
            <p>Reach emergency helplines, headquarters, and find Police Stations, PKM Centers, and Police Offices across Islamabad.</p>
        </div>
    </section>

    <nav class="contact-breadcrumb" aria-label="Breadcrumb">
        <div class="container">
            <a href="index.php">Home</a>
            <span class="sep">/</span>
            <span class="text-muted">Contact</span>
        </div>
    </nav>

        <section class="contact-section surface" id="helplines">
        <div class="container">
            <div class="contact-section-head">
                <h2><i class="fas fa-phone-volume me-2 text-primary"></i>Emergency Helplines</h2>
                <p>Tap a number to call instantly from your phone</p>
            </div>
            <div class="helpline-grid">
                                <a class="helpline-card" href="tel:15">
                    <span class="helpline-icon"><i class="fas fa-phone-volume"></i></span>
                    <p class="label">Emergency</p>
                    <p class="number">15</p>
                                            <span class="cta">Call now <i class="fas fa-arrow-right ms-1"></i></span>
                                    </a>
                                <a class="helpline-card" href="tel:1715">
                    <span class="helpline-icon"><i class="fas fa-phone-alt"></i></span>
                    <p class="label">IGP Helpline</p>
                    <p class="number">1715</p>
                                            <span class="cta">Call now <i class="fas fa-arrow-right ms-1"></i></span>
                                    </a>
                                <a class="helpline-card" href="tel:1815">
                    <span class="helpline-icon"><i class="fas fa-users"></i></span>
                    <p class="label">Online Women Helpline</p>
                    <p class="number">1815</p>
                                            <span class="cta">Call now <i class="fas fa-arrow-right ms-1"></i></span>
                                    </a>
                                <a class="helpline-card" href="tel:1915">
                    <span class="helpline-icon"><i class="fas fa-car"></i></span>
                    <p class="label">ITP Helpline</p>
                    <p class="number">1915</p>
                                            <span class="cta">Call now <i class="fas fa-arrow-right ms-1"></i></span>
                                    </a>
                            </div>
        </div>
    </section>
    
    <section class="contact-section white" id="office-info">
        <div class="container">
            <div class="contact-section-head">
                <h2><i class="fas fa-building me-2 text-primary"></i>Headquarters &amp; Office Information</h2>
                <p>Official contact details for Islamabad Police Headquarters</p>
            </div>
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="info-panel h-100">
                        <div class="info-panel-head">
                            <h3><i class="fas fa-landmark me-2"></i>CPO &amp; Office Details</h3>
                        </div>
                        <ul class="info-list">
                                                        <li>
                                <span class="ico"><i class="fas fa-map-marker-alt"></i></span>
                                <div>
                                    <p class="title">Headquarters Address</p>
                                                                            <a class="value" href="tel:11">Police Lines Headquarters, Sector H-11, Islamabad</a>
                                                                    </div>
                            </li>
                                                        <li>
                                <span class="ico"><i class="fas fa-phone"></i></span>
                                <div>
                                    <p class="title">General Inquiry</p>
                                                                            <a class="value" href="tel:0519259370">051-9259370</a>
                                                                    </div>
                            </li>
                                                        <li>
                                <span class="ico"><i class="fas fa-envelope"></i></span>
                                <div>
                                    <p class="title">Email</p>
                                                                            <a class="value" href="mailto:info@islamabadpolice.gov.pk">info@islamabadpolice.gov.pk</a>
                                                                    </div>
                            </li>
                                                                                </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="info-panel h-100">
                        <div class="info-panel-head">
                            <h3><i class="fas fa-share-alt me-2"></i>Stay Connected</h3>
                        </div>
                        <div class="p-4">
                            <p class="text-muted mb-3" style="font-size:0.95rem;line-height:1.6;">
                                Follow Islamabad Police for official updates, advisories, and public information.
                            </p>
                            <div class="social-row">
                                                                                                            <a class="social-chip" href="https://www.facebook.com/islamabadpolice/" target="_blank" rel="noopener noreferrer">
                                            <i class="fab fa-facebook-f"></i>
                                            Facebook                                        </a>
                                                                            <a class="social-chip" href="https://twitter.com/islamabadpolice" target="_blank" rel="noopener noreferrer">
                                            <i class="fab fa-twitter"></i>
                                            Twitter                                        </a>
                                                                            <a class="social-chip" href="https://www.instagram.com/islamabadpolice/" target="_blank" rel="noopener noreferrer">
                                            <i class="fab fa-instagram"></i>
                                            Instagram                                        </a>
                                                                            <a class="social-chip" href="https://www.youtube.com/c/IslamabadPolice1" target="_blank" rel="noopener noreferrer">
                                            <i class="fab fa-youtube"></i>
                                            YouTube                                        </a>
                                                                                                </div>
                            <div class="mt-4">
                                <a href="index.php#locator" class="btn btn-outline-primary w-100">
                                    <i class="fas fa-map-marker-alt me-2"></i>Open Interactive Map
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="contact-section surface" id="locations">
        <div class="container">
            <div class="contact-section-head">
                <h2><i class="fas fa-map-marked-alt me-2 text-primary"></i>Find Locations</h2>
                <p>Browse Police Stations, PKM Centers, and Police Offices</p>
            </div>

            <div class="loc-toolbar">
                <div class="loc-tabs" role="tablist" aria-label="Location type">
                    <button type="button" class="loc-tab active" data-tab="pkm" role="tab" aria-selected="true">
                        PKM <span class="count">11</span>
                    </button>
                    <button type="button" class="loc-tab" data-tab="office" role="tab" aria-selected="false">
                        Offices <span class="count">13</span>
                    </button>
                    <button type="button" class="loc-tab" data-tab="ps" role="tab" aria-selected="false">
                        Stations <span class="count">27</span>
                    </button>
                </div>
                <div class="loc-search">
                    <i class="fas fa-search"></i>
                    <input type="search" id="locSearch" placeholder="Search by name, address, or phone…" aria-label="Search locations">
                </div>
            </div>

                        <div class="loc-panel active" id="panel-pkm" data-panel="pkm">
                <div class="loc-grid">
                                                                    <article class="loc-card" data-search="chamber of commerce (g-8) police khidmat markaz, islamabad chamber of commerce, g-8/1 051-9259022 learner permit, character certificate, tenant registration, foreigner registration, lost/missing report 08:30 am - 05:00 pm">
                            <h4>Chamber of Commerce (G-8)</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>08:30 AM - 05:00 PM</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Police Khidmat Markaz, Islamabad Chamber of Commerce, G-8/1</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner Permit, Character Certificate, Tenant Registration, Foreigner Registration, Lost/Missing Report</p>
                                                                                                                            <a class="loc-phone" href="tel:0519259022"><i class="fas fa-phone me-1"></i>051-9259022</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="pkm cascade pkm isfahani rd, diplomatic enclave, islamabad, pakistan 051-9259022 learner, renewal, duplicate, conversion, endorsement, driving test &amp; printing, character certificate, tenant registration, foreigner registration, lost/missing report 24/7">
                            <h4>PKM Cascade</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>PKM Isfahani Rd, Diplomatic Enclave, Islamabad, Pakistan</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner, Renewal, Duplicate, Conversion, Endorsement, Driving Test &amp; Printing, Character Certificate, Tenant Registration, Foreigner Registration, Lost/Missing Report</p>
                                                                                                                            <a class="loc-phone" href="tel:0519259022"><i class="fas fa-phone me-1"></i>051-9259022</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="pkm gulberg green pkm gulburg 051-9259022 learner, renewal, duplicate, conversion, driving test, international driving permit, character certificate, tenant registration, foreigner registration, lost/missing report 08:30 am - 05:00 pm">
                            <h4>PKM Gulberg Green</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>08:30 AM - 05:00 PM</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>PKM Gulburg</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner, Renewal, Duplicate, Conversion, Driving Test, International Driving Permit, Character Certificate, Tenant Registration, Foreigner Registration, Lost/Missing Report</p>
                                                                                                                            <a class="loc-phone" href="tel:0519259022"><i class="fas fa-phone me-1"></i>051-9259022</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="pkm f-6 near super market 051-9201522 / islamabad.psc@gmail.com learner, renewal, duplicate, conversion, endorsement, driving test &amp; printing, international driving permit, character certificate, tenant registration, foreigner registration, vehicle verification, employee registration, lost/missing report, copy of fir 24/7">
                            <h4>PKM F-6</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Near Super Market</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner, Renewal, Duplicate, Conversion, Endorsement, Driving Test &amp; Printing, International Driving Permit, Character Certificate, Tenant Registration, Foreigner Registration, Vehicle Verification, Employee Registration, Lost/Missing Report, Copy of FIR</p>
                                                                                                                            <a class="loc-phone" href="tel:0519201522"><i class="fas fa-phone me-1"></i>051-9201522 / islamabad.psc@gmail.com</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="pkm h-11 (police lines) h-11 051-9259022 learner, duplicate &amp; renewal &amp; driving test sheet, character certificate, tenant registration, foreigner registration, lost/missing report 08:30 am - 05:00 pm">
                            <h4>PKM H-11 (Police Lines)</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>08:30 AM - 05:00 PM</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>H-11</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner, Duplicate &amp; Renewal &amp; Driving Test Sheet, Character Certificate, Tenant Registration, Foreigner Registration, Lost/Missing Report</p>
                                                                                                                            <a class="loc-phone" href="tel:0519259022"><i class="fas fa-phone me-1"></i>051-9259022</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="pkm bani gala banigala 0300-7980325 learner, duplicate &amp; renewal, character certificate, tenant registration, foreigner registration, lost/missing report 08:30 am - 05:00 pm">
                            <h4>PKM Bani Gala</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>08:30 AM - 05:00 PM</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Banigala</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner, Duplicate &amp; Renewal, Character Certificate, Tenant Registration, Foreigner Registration, Lost/Missing Report</p>
                                                                                                                            <a class="loc-phone" href="tel:03007980325"><i class="fas fa-phone me-1"></i>0300-7980325</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="pkm khanna khanna pull, near police station khanna, islamabad 0514473600 learner, duplicate &amp; renewal, character certificate, tenant registration, foreigner registration, lost/missing report 08:30 am - 05:00 pm">
                            <h4>PKM Khanna</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>08:30 AM - 05:00 PM</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Khanna Pull, near Police Station Khanna, Islamabad</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner, Duplicate &amp; Renewal, Character Certificate, Tenant Registration, Foreigner Registration, Lost/Missing Report</p>
                                                                                                                            <a class="loc-phone" href="tel:0514473600"><i class="fas fa-phone me-1"></i>0514473600</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="pkm g-14/4 g-14 --- learner, duplicate &amp; renewal &amp; driving test sheet, character certificate, tenant registration, foreigner registration, lost/missing report 08:30 am - 05:00 pm">
                            <h4>PKM G-14/4</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>08:30 AM - 05:00 PM</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>G-14</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner, Duplicate &amp; Renewal &amp; Driving Test Sheet, Character Certificate, Tenant Registration, Foreigner Registration, Lost/Missing Report</p>
                                                                                                                            <span class="loc-phone"><i class="fas fa-phone me-1"></i>---</span>
                                                                                    </article>
                                                <article class="loc-card" data-search="pkm soan garden soan garden 051-9259022 learner, duplicate &amp; renewal &amp; driving test sheet, character certificate, tenant registration, foreigner registration, lost/missing report 08:30 am - 05:00 pm">
                            <h4>PKM Soan Garden</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>08:30 AM - 05:00 PM</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Soan Garden</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner, Duplicate &amp; Renewal &amp; Driving Test Sheet, Character Certificate, Tenant Registration, Foreigner Registration, Lost/Missing Report</p>
                                                                                                                            <a class="loc-phone" href="tel:0519259022"><i class="fas fa-phone me-1"></i>051-9259022</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="dc office g-11 g-11 dc office 051-9259022 character certificate, tenant registration, foreigner registration, lost/missing report 08:30 am - 05:00 pm">
                            <h4>DC Office G-11</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>08:30 AM - 05:00 PM</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>G-11 DC Office</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Character Certificate, Tenant Registration, Foreigner Registration, Lost/Missing Report</p>
                                                                                                                            <a class="loc-phone" href="tel:0519259022"><i class="fas fa-phone me-1"></i>051-9259022</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="pakistan asaan markaz g-9 g-9 markaz, islamabad 051-9259022 learner, duplicate &amp; renewal &amp; driving test sheet, character certificate, tenant registration, foreigner registration, lost/missing report 08:00 am - 08:00 pm">
                            <h4>Pakistan Asaan Markaz G-9</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>08:00 AM - 08:00 PM</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>G-9 Markaz, Islamabad</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner, Duplicate &amp; Renewal &amp; Driving Test Sheet, Character Certificate, Tenant Registration, Foreigner Registration, Lost/Missing Report</p>
                                                                                                                            <a class="loc-phone" href="tel:0519259022"><i class="fas fa-phone me-1"></i>051-9259022</a>
                                                                                    </article>
                                                            </div>
                <div class="loc-empty" data-empty-for="pkm">No matching locations. Try another search.</div>
            </div>
                        <div class="loc-panel" id="panel-office" data-panel="office">
                <div class="loc-grid">
                                                                    <article class="loc-card" data-search="dig operations islamabad mauve area g 11/4 g-11, islamabad, pakistan 051-9108370 0">
                            <h4>DIG Operations Islamabad</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Mauve Area G 11/4 G-11, Islamabad, Pakistan</p>
                                                                                                                                                        <a class="loc-phone" href="tel:0519108370"><i class="fas fa-phone me-1"></i>051-9108370</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="sp city office, islamabad police khayaban-e-suhrwardy rd, ramna 5 islamabad, 44000, pakistan 051-9246699 0">
                            <h4>SP City Office, Islamabad Police</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Khayaban-e-Suhrwardy Rd, Ramna 5 Islamabad, 44000, Pakistan</p>
                                                                                                                                                        <a class="loc-phone" href="tel:0519246699"><i class="fas fa-phone me-1"></i>051-9246699</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="sp office industrial area nusrat fatah ali khan rd, markaz i-8, islamabad, pakistan 051-9334929 0">
                            <h4>SP Office Industrial Area</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Nusrat Fatah Ali Khan Rd, Markaz I-8, Islamabad, Pakistan</p>
                                                                                                                                                        <a class="loc-phone" href="tel:0519334929"><i class="fas fa-phone me-1"></i>051-9334929</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="sp office soan zone khanna islamabad, pakistan 051-2326115 0">
                            <h4>SP Office Soan Zone</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Khanna Islamabad, Pakistan</p>
                                                                                                                                                        <a class="loc-phone" href="tel:0512326115"><i class="fas fa-phone me-1"></i>051-2326115</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="sp rural office islamabad sp rural office, , koral town, islamabad, pakistan o51- 2326115 0">
                            <h4>SP Rural Office Islamabad</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>SP Rural Office, , Koral Town, Islamabad, Pakistan</p>
                                                                                                                                                        <a class="loc-phone" href="tel:512326115"><i class="fas fa-phone me-1"></i>O51- 2326115</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="sp saddar zone office islamabad sp saddar zone office g-10 markaz, , islamabad, pakistan 051-9330225 0">
                            <h4>SP Saddar Zone Office Islamabad</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>SP Saddar Zone Office G-10 Markaz, , Islamabad, Pakistan</p>
                                                                                                                                                        <a class="loc-phone" href="tel:0519330225"><i class="fas fa-phone me-1"></i>051-9330225</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ssp operations office islamabad mauve area g 11/4 g-11, islamabad, pakistan 051-9108191 0">
                            <h4>SSP Operations office Islamabad</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Mauve Area G 11/4 G-11, Islamabad, Pakistan</p>
                                                                                                                                                        <a class="loc-phone" href="tel:0519108191"><i class="fas fa-phone me-1"></i>051-9108191</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="safe city islamabad safe city, sector h-11/4, islamabad, pakistan 051-9001521 / dg.sc@islamabadpolice.gov.pk 24/7 city-wide surveillance and monitoring via cctv; traffic monitoring; emergency coordination.">
                            <h4>Safe City Islamabad</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Safe City, Sector H-11/4, Islamabad, Pakistan</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>24/7 city-wide surveillance and monitoring via CCTV; traffic monitoring; emergency coordination.</p>
                                                                                                                            <a class="loc-phone" href="tel:0519001521"><i class="fas fa-phone me-1"></i>051-9001521 / dg.sc@islamabadpolice.gov.pk</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="islamabad police headquarters police lines, sector h-11, islamabad 051-4440037-39 central command and administration for ict policing; law enforcement oversight; public assistance.">
                            <h4>Islamabad Police Headquarters</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Police Lines, Sector H-11, Islamabad</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Central command and administration for ICT policing; law enforcement oversight; public assistance.</p>
                                                                                                                            <a class="loc-phone" href="tel:051444003739"><i class="fas fa-phone me-1"></i>051-4440037-39</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="traffic hq faizabad shakar pariyan faizabad, islamabad 051-92619923 learner, renewal, duplicate, conversion, endorsement, noc, driving test &amp; printing, international driving permit through dc office facilitation van 08:30 am - 05:00 pm">
                            <h4>Traffic HQ Faizabad</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>08:30 AM - 05:00 PM</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Shakar Pariyan Faizabad, Islamabad</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Learner, Renewal, Duplicate, Conversion, Endorsement, NOC, Driving Test &amp; Printing, International Driving Permit through DC Office Facilitation Van</p>
                                                                                                                            <a class="loc-phone" href="tel:05192619923"><i class="fas fa-phone me-1"></i>051-92619923</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="counter terrorism department ctd complex, sector h-11, islamabad 051-9259014-15 counter-terrorism operations and intelligence.">
                            <h4>Counter Terrorism Department</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>CTD Complex, Sector H-11, Islamabad</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>Counter-terrorism operations and intelligence.</p>
                                                                                                                            <a class="loc-phone" href="tel:051925901415"><i class="fas fa-phone me-1"></i>051-9259014-15</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="security division hq diplomatic enclave (dpd) 0519246600 0">
                            <h4>Security Division HQ</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Diplomatic Enclave (DPD)</p>
                                                                                                                                                        <a class="loc-phone" href="tel:0519246600"><i class="fas fa-phone me-1"></i>0519246600</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="special branch sector g-7 markaz, islamabad  0">
                            <h4>Special Branch</h4>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Sector G-7 Markaz, Islamabad</p>
                                                                                                            </article>
                                                            </div>
                <div class="loc-empty" data-empty-for="office">No matching locations. Try another search.</div>
            </div>
                        <div class="loc-panel" id="panel-ps" data-panel="ps">
                <div class="loc-grid">
                                                                    <article class="loc-card" data-search="ps kirpa in koral police station 0512326066 general policing 24/7">
                            <h4>PS Kirpa</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>in Koral Police Station</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0512326066"><i class="fas fa-phone me-1"></i>0512326066</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps phulgaran in bara kahu police station 03324488888 general policing 24/7">
                            <h4>PS Phulgaran</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>in Bara Kahu Police Station</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:03324488888"><i class="fas fa-phone me-1"></i>03324488888</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps sangjani near sangjani stop, gt road 0512296128 general policing 24/7">
                            <h4>PS Sangjani</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Near Sangjani Stop, GT Road</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0512296128"><i class="fas fa-phone me-1"></i>0512296128</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps aabpara aabpara (melody / near poly clinic hospital) 051-9204830 general policing 24/7">
                            <h4>PS Aabpara</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Aabpara (Melody / Near Poly Clinic Hospital)</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519204830"><i class="fas fa-phone me-1"></i>051-9204830</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps karachi company g-9 markaz 051-9334091 general policing 24/7">
                            <h4>PS Karachi Company</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>G-9 Markaz</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519334091"><i class="fas fa-phone me-1"></i>051-9334091</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps kohsar f-7 markaz 051-9102499 general policing 24/7">
                            <h4>PS Kohsar</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>F-7 Markaz</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519102499"><i class="fas fa-phone me-1"></i>051-9102499</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps margalla f-8 markaz 051-9261510 general policing 24/7">
                            <h4>PS Margalla</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>F-8 Markaz</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519261510"><i class="fas fa-phone me-1"></i>051-9261510</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps secretariat g-5 markaz (near presidency / pm house) 051-9209132 general policing 24/7">
                            <h4>PS Secretariat</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>G-5 Markaz (Near Presidency / PM House)</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519209132"><i class="fas fa-phone me-1"></i>051-9209132</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps women police station g-7 markaz 051-9252517 general policing 24/7">
                            <h4>PS Women Police Station</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>G-7 Markaz</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519252517"><i class="fas fa-phone me-1"></i>051-9252517</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps golra sharif golra sharif village 051-9267099 general policing 24/7">
                            <h4>PS Golra Sharif</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Golra Sharif Village</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519267099"><i class="fas fa-phone me-1"></i>051-9267099</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps ramna g-11 051-9330189 general policing 24/7">
                            <h4>PS Ramna</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>G-11</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519330189"><i class="fas fa-phone me-1"></i>051-9330189</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps shalimar f-10/2 (street 8, school chowk) 051-9266885 general policing 24/7">
                            <h4>PS Shalimar</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>F-10/2 (Street 8, School Chowk)</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519266885"><i class="fas fa-phone me-1"></i>051-9266885</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps sumbal g-13 markaz  general policing 24/7">
                            <h4>PS Sumbal</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>G-13 Markaz</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                </article>
                                                <article class="loc-card" data-search="ps tarnol gt road 051-2295122 general policing 24/7">
                            <h4>PS Tarnol</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>GT Road</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0512295122"><i class="fas fa-phone me-1"></i>051-2295122</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps industrial area i-9 i-9 industrial area 051-9258877 general policing 24/7">
                            <h4>PS Industrial Area I-9</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>I-9 Industrial Area</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519258877"><i class="fas fa-phone me-1"></i>051-9258877</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps noon i-16 markaz  general policing 24/7">
                            <h4>PS Noon</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>I-16 Markaz</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                </article>
                                                <article class="loc-card" data-search="ps sabzi mandi i-10 green belt (near sabzi mandi) 051-9334840 general policing 24/7">
                            <h4>PS Sabzi Mandi</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>I-10 Green Belt (near Sabzi Mandi)</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519334840"><i class="fas fa-phone me-1"></i>051-9334840</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps shamas colony n/a 051-9334499 general policing 24/7">
                            <h4>PS Shamas Colony</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>N/A</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519334499"><i class="fas fa-phone me-1"></i>051-9334499</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps bani gala park road (shehzad town) 051-9255339 general policing 24/7">
                            <h4>PS Bani Gala</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Park Road (Shehzad Town)</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519255339"><i class="fas fa-phone me-1"></i>051-9255339</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps bara kahu simli road 051-2230029 general policing 24/7">
                            <h4>PS Bara Kahu</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Simli Road</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0512230029"><i class="fas fa-phone me-1"></i>051-2230029</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps nilore nilore  general policing 24/7">
                            <h4>PS Nilore</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Nilore</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                </article>
                                                <article class="loc-card" data-search="ps shahzad town shahzad town 051-9247444 general policing 24/7">
                            <h4>PS Shahzad Town</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Shahzad Town</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519247444"><i class="fas fa-phone me-1"></i>051-9247444</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps humak t-chowk, dha phase ii  general policing 24/7">
                            <h4>PS Humak</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>T-Chowk, DHA Phase II</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                </article>
                                                <article class="loc-card" data-search="ps khanna khanna pul (expressway) 051-4473600 general policing 24/7">
                            <h4>PS Khanna</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Khanna Pul (Expressway)</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0514473600"><i class="fas fa-phone me-1"></i>051-4473600</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps koral koral chowk 051-9252517 general policing 24/7">
                            <h4>PS Koral</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Koral Chowk</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0519252517"><i class="fas fa-phone me-1"></i>051-9252517</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps lohi bher cbr town 051-5710906 general policing 24/7">
                            <h4>PS Lohi Bher</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>CBR Town</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0515710906"><i class="fas fa-phone me-1"></i>051-5710906</a>
                                                                                    </article>
                                                <article class="loc-card" data-search="ps sihala kahuta road (near kak pul) 051-4491334 general policing 24/7">
                            <h4>PS Sihala</h4>
                                                            <p class="loc-meta"><i class="far fa-clock"></i>24/7</p>
                                                                                        <p class="loc-meta"><i class="fas fa-map-marker-alt"></i>Kahuta Road (near Kak Pul)</p>
                                                                                        <p class="loc-meta"><i class="fas fa-list-check"></i>General Policing</p>
                                                                                                                            <a class="loc-phone" href="tel:0514491334"><i class="fas fa-phone me-1"></i>051-4491334</a>
                                                                                    </article>
                                                            </div>
                <div class="loc-empty" data-empty-for="ps">No matching locations. Try another search.</div>
            </div>
            
            <div class="loc-map-cta">
                <a href="index.php#locator"><i class="fas fa-location-arrow"></i> Find nearest location on map</a>
            </div>
        </div>
    </section>
</div>

<script>
(function () {
    const tabs = document.querySelectorAll('.loc-tab');
    const panels = document.querySelectorAll('.loc-panel');
    const searchInput = document.getElementById('locSearch');

    function activePanel() {
        return document.querySelector('.loc-panel.active');
    }

    function filterCards() {
        const panel = activePanel();
        if (!panel) return;
        const q = (searchInput?.value || '').trim().toLowerCase();
        const cards = panel.querySelectorAll('.loc-card');
        let visible = 0;
        cards.forEach(card => {
            const hay = card.getAttribute('data-search') || '';
            const show = !q || hay.includes(q);
            card.style.display = show ? '' : 'none';
            if (show) visible++;
        });
        const empty = panel.querySelector('.loc-empty[data-empty-for]');
        if (empty) {
            empty.classList.toggle('show', visible === 0 && cards.length > 0);
        }
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const key = tab.getAttribute('data-tab');
            tabs.forEach(t => {
                t.classList.toggle('active', t === tab);
                t.setAttribute('aria-selected', t === tab ? 'true' : 'false');
            });
            panels.forEach(p => {
                p.classList.toggle('active', p.getAttribute('data-panel') === key);
            });
            filterCards();
        });
    });

    searchInput?.addEventListener('input', filterCards);
})();
</script>

<script>
document.title = 'Contact Us | ICT Police';
</script>

<footer class="bg-dark text-white py-5" id="site-footer">
    <div class="container">
        <div class="row g-4 mb-4">
            <div class="col-lg-4 footer-section">
                <img src="assets/images/Capital_Territory_Police.png" alt="ICT Police" height="72" class="mb-3">
                <h5 class="fw-bold text-gold mb-3">Islamabad Capital Territory Police</h5>
                <p class="small text-white-50 mb-0">
                    Serving citizens with integrity, innovation, and community-focused policing across Islamabad.
                </p>
            </div>

            <div class="col-lg-4 footer-section">
                <h5 class="fw-bold mb-3">Quick Links</h5>
                <ul class="list-unstyled footer-links mb-0">
                                        <li class="mb-2">
                        <a href="index.php#online-services" class="footer-link">
                                                            <i class="fas fa-laptop-house me-2"></i>
                                                        Citizen Services                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="index.php#locator" class="footer-link">
                                                            <i class="fas fa-map-marker-alt me-2"></i>
                                                        Find PS / PKM                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="media.php" class="footer-link">
                                                            <i class="fas fa-newspaper me-2"></i>
                                                        News &amp; Media                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="notices.php" class="footer-link">
                                                            <i class="fas fa-briefcase me-2"></i>
                                                        Jobs, Tenders &amp; Auctions                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="contact.php" class="footer-link">
                                                            <i class="fas fa-headset me-2"></i>
                                                        Contact Us                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="igp-message.php" class="footer-link">
                                                            <i class="fas fa-user-shield me-2"></i>
                                                        IGP Message                        </a>
                    </li>
                                    </ul>
            </div>

            <div class="col-lg-4 footer-section">
                <h5 class="fw-bold mb-3">Emergency Helplines</h5>
                <ul class="list-unstyled footer-helplines mb-4">
                                        <li class="mb-2">
                        <a href="tel:15" class="footer-link">
                            <i class="fas fa-phone-volume me-2 text-gold"></i>
                            <strong>Emergency:</strong>
                            15                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="tel:1715" class="footer-link">
                            <i class="fas fa-phone-alt me-2 text-gold"></i>
                            <strong>IGP Helpline:</strong>
                            1715                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="tel:1815" class="footer-link">
                            <i class="fas fa-users me-2 text-gold"></i>
                            <strong>Online Women Helpline:</strong>
                            1815                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="tel:1915" class="footer-link">
                            <i class="fas fa-car me-2 text-gold"></i>
                            <strong>ITP Helpline:</strong>
                            1915                        </a>
                    </li>
                                    </ul>
                <div class="footer-social d-flex gap-2 flex-wrap">
                    <a href="https://www.facebook.com/islamabadpolice" target="_blank" rel="noopener" class="social-btn" aria-label="Facebook">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="https://twitter.com/ICT_Police" target="_blank" rel="noopener" class="social-btn" aria-label="X">
                        <i class="fab fa-x-twitter"></i>
                    </a>
                    <a href="https://www.instagram.com/islamabadpolice/" target="_blank" rel="noopener" class="social-btn" aria-label="Instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="https://www.youtube.com/c/IslamabadPolice1" target="_blank" rel="noopener" class="social-btn" aria-label="YouTube">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
        </div>

        <hr class="border-secondary opacity-50">

        <div class="row align-items-center pt-2">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0 small text-white-50">
                    <i class="fas fa-copyright me-2"></i>2026 Islamabad Capital Territory Police. All Rights Reserved.
                </p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <p class="mb-0 small text-white-50">
                    Developed by <strong class="text-gold">Safe City Islamabad</strong>
                </p>
            </div>
        </div>
    </div>
</footer>

<style>
.bg-dark {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%) !important;
}
.text-gold { color: #D4AF37 !important; }
.footer-link {
    color: rgba(255, 255, 255, 0.82);
    text-decoration: none;
    font-size: 0.95rem;
    transition: color 0.2s ease;
}
.footer-link:hover { color: #D4AF37; }
.social-btn {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 0.1);
    color: #fff;
    text-decoration: none;
    transition: background 0.2s ease, transform 0.2s ease;
}
.social-btn:hover {
    background: #D4AF37;
    color: #0f172a;
    transform: translateY(-2px);
}
@media (max-width: 992px) {
    .footer-section h5 { text-align: center; }
}
@media (max-width: 576px) {
    .footer-section { text-align: center; }
    .footer-social { justify-content: center; }
}
</style>


<a href="https://wa.me/923326001069?text=Hello%2C%20I%20would%20like%20to%20chat%20with%20ICT%20Police."
   class="ict-whatsapp-float"
   id="ictWhatsAppFloat"
   target="_blank"
   rel="noopener noreferrer"
   aria-label="Chat on WhatsApp — +92 332 6001069">
    <span class="ict-whatsapp-float__pulse" aria-hidden="true"></span>
    <i class="fab fa-whatsapp" aria-hidden="true"></i>
    <span class="ict-whatsapp-float__label">Live Chat</span>
</a>

<style>
.ict-whatsapp-float {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 9999;
    display: inline-flex;
    align-items: center;
    gap: 0.65rem;
    padding: 0.85rem 1.15rem 0.85rem 0.95rem;
    border-radius: 999px;
    background: linear-gradient(135deg, #25d366 0%, #128c7e 100%);
    color: #fff !important;
    text-decoration: none;
    font-weight: 600;
    font-size: 0.95rem;
    line-height: 1;
    box-shadow:
        0 8px 24px rgba(37, 211, 102, 0.45),
        0 2px 8px rgba(0, 0, 0, 0.15);
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
}

.ict-whatsapp-float:hover {
    transform: translateY(-3px) scale(1.02);
    color: #fff !important;
    box-shadow:
        0 12px 28px rgba(37, 211, 102, 0.5),
        0 4px 12px rgba(0, 0, 0, 0.18);
}

.ict-whatsapp-float:focus-visible {
    outline: 3px solid #d4af37;
    outline-offset: 3px;
}

.ict-whatsapp-float i {
    font-size: 1.65rem;
}

.ict-whatsapp-float__label {
    letter-spacing: 0.02em;
}

.ict-whatsapp-float__pulse {
    position: absolute;
    inset: 0;
    border-radius: 999px;
    background: rgba(37, 211, 102, 0.35);
    animation: ict-whatsapp-pulse 2.2s ease-out infinite;
    pointer-events: none;
}

@keyframes ict-whatsapp-pulse {
    0% {
        transform: scale(1);
        opacity: 0.7;
    }
    70% {
        transform: scale(1.35);
        opacity: 0;
    }
    100% {
        transform: scale(1.35);
        opacity: 0;
    }
}

@media (max-width: 575.98px) {
    .ict-whatsapp-float {
        padding: 0.75rem;
        border-radius: 50%;
        width: 56px;
        height: 56px;
        justify-content: center;
    }

    .ict-whatsapp-float__label {
        display: none;
    }

    .ict-whatsapp-float i {
        font-size: 1.75rem;
    }
}
</style>

<script>
(function () {
    var btn = document.getElementById('ictWhatsAppFloat');
    if (!btn) {
        return;
    }

    function isMobileView() {
        return window.matchMedia('(max-width: 575.98px)').matches;
    }

    function resetDesktopPosition() {
        btn.style.removeProperty('left');
        btn.style.removeProperty('top');
        btn.style.removeProperty('right');
        btn.style.removeProperty('bottom');
    }

    function pinWhatsApp() {
        if (!isMobileView() || !window.visualViewport) {
            resetDesktopPosition();
            return;
        }

        var vv = window.visualViewport;
        var margin = 16;
        var w = btn.offsetWidth || 56;
        var h = btn.offsetHeight || 56;
        var left = vv.offsetLeft + vv.width - w - margin;
        var top = vv.offsetTop + vv.height - h - margin;

        btn.style.setProperty('left', Math.round(left) + 'px', 'important');
        btn.style.setProperty('top', Math.round(top) + 'px', 'important');
        btn.style.setProperty('right', 'auto', 'important');
        btn.style.setProperty('bottom', 'auto', 'important');
    }

    window.ictPinWhatsApp = pinWhatsApp;

    if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', pinWhatsApp, { passive: true });
        window.visualViewport.addEventListener('scroll', pinWhatsApp, { passive: true });
    }
    window.addEventListener('resize', pinWhatsApp, { passive: true });
    window.addEventListener('orientationchange', pinWhatsApp, { passive: true });
    window.addEventListener('scroll', pinWhatsApp, { passive: true });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', pinWhatsApp);
    } else {
        pinWhatsApp();
    }
})();
</script>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({ duration: 1000, once: true });

        function animateHeroContent(slide) {
            if (!slide) return;
            const content = slide.querySelector('.hero-content');
            if (!content) return;
            content.classList.remove('is-visible');
            void content.offsetWidth;
            content.classList.add('is-visible');
        }

        const heroSliderEl = document.querySelector('.hero-slider');
        if (heroSliderEl) {
            new Swiper('.hero-slider', {
                loop: true,
                autoplay: { delay: 4000 },
                pagination: { el: '.swiper-pagination', clickable: true },
                speed: 700,
                on: {
                    init(swiper) {
                        animateHeroContent(swiper.slides[swiper.activeIndex]);
                    },
                    slideChangeTransitionStart(swiper) {
                        swiper.slides.forEach(slide => {
                            const content = slide.querySelector('.hero-content');
                            if (content) content.classList.remove('is-visible');
                        });
                    },
                    slideChangeTransitionEnd(swiper) {
                        animateHeroContent(swiper.slides[swiper.activeIndex]);
                    },
                },
            });
        }

        const navbar = document.querySelector('.navbar');
        if (navbar) {
            window.addEventListener('scroll', () => {
                navbar.classList.toggle('sticky', window.scrollY > 0);
            }, { passive: true });
        }
    </script>
</body>
</html>
