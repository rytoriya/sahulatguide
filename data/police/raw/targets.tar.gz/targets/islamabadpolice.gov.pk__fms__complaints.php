<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Islamabad Capital Police – Public Complaint Registration</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- Font Awesome -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Noto+Nastaliq+Urdu:wght@400;600&display=swap" rel="stylesheet" />
  <!-- Custom CSS -->
  <link rel="stylesheet" href="style.css" />
</head>

<body>


  <!-- ===== MAIN WRAPPER ===== -->
  <main class="main-wrapper">
    <div class="split-container">

      <!-- ===== LEFT PANEL ===== -->
      <aside class="left-panel">
        <div class="left-inner">
          <!-- Logo Section -->
          <div class="logo-section" data-aos="fade-down">
            <img src="logo.png" class="icp-logo" alt="Islamabad Capital Police Logo"><br>
            <h3 class="logo-heading" style="color: white;">Islamabad Capital Police</h3>
          </div>

          <!-- Divider -->
          <div class="panel-divider"></div>

          <!-- 24/7 Support Section -->
          <div class="support-section" data-aos="fade-up" data-aos-delay="100">
            <img src="24-7-image.png" alt="24/7 Support" class="support-image">
            <h2 class="support-heading">Always Available</h2>
            <p class="support-subtitle">24/7 Citizens Support</p>
          </div>

          <!-- Trust Badges -->
          <div class="trust-badges" data-aos="fade-up" data-aos-delay="200">
            <div class="badge-item">
              <div class="badge-icon"><i class="fas fa-shield-alt"></i></div>
              <span class="badge-text">100% Secure</span>
            </div>
            <div class="badge-item">
              <div class="badge-icon"><i class="fas fa-lock"></i></div>
              <span class="badge-text">Confidential</span>
            </div>
            <div class="badge-item">
              <div class="badge-icon"><i class="fas fa-check-circle"></i></div>
              <span class="badge-text">Verified</span>
            </div>
          </div>
          <div>
            <span style="color: #f5f5f5;">Developed By: Safe City Islamabad</span>
          </div>
          <!-- Features List -->
          <!-- 
          <div class="contact-section" data-aos="fade-up" data-aos-delay="400">
            <p class="contact-heading">Need Help?</p>
            <a href="tel:051-9258000" class="contact-link">
              <i class="fas fa-phone me-2"></i>051-9258000
            </a>
          </div>
        </div> -->
      </aside>

      <!-- ===== RIGHT PANEL – FORM ===== -->
      <section class="right-panel">
        <div class="form-card">
          <div class="form-card-header">
            <div>
              <h3 class="form-title">Submit your complaint</h3>
              <p class="form-title-urdu">اپنی شکایت درج کریں</p>
            </div>
            <button type="button" class="form-badge" id="checkStatusBtn" data-bs-toggle="modal" data-bs-target="#checkStatusModal">
              <i class="fas fa-shield-alt me-1"></i>Check Status
            </button>
          </div>

          <form id="complaintForm" novalidate>

            <!-- Hidden fields for circle_id and zone_id -->
            <input type="hidden" id="circle_id" name="circle_id" value="" />
            <input type="hidden" id="zone_id" name="zone_id" value="" />

            <!-- Row 1: City | Police Station | Complainant Address -->
            <div class="row g-3 form-row-animated" style="--delay:0.05s">
              <div class="col-md-4 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-city label-icon"></i>City <span class="req">*</span></span>
                    <span class="lbl-ur">شہر</span>
                  </div>
                  <select class="form-control icp-select" id="city" name="city" required>
                    <option value="">Select City</option>
                  </select>
                  <div class="invalid-feedback">Please select a city.</div>
                </div>
              </div>
              <div class="col-md-4 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-building label-icon"></i>Police Station <span class="req">*</span></span>
                    <span class="lbl-ur">تھانہ</span>
                  </div>
                  <select class="form-control icp-select" id="policeStation" name="policeStation" required>
                    <option value="">Please select your police station...</option>
                  </select>
                  <div class="invalid-feedback">Please select a police station.</div>
                </div>
              </div>
              <div class="col-md-4 col-sm-12">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-map-marker-alt label-icon"></i>Complainant Address <span class="req">*</span></span>
                    <span class="lbl-ur">شکایت کنندہ کا پتہ</span>
                  </div>
                  <input type="text" class="form-control icp-input" id="complainantAddress" name="complainantAddress"
                    placeholder="Type your address here" required minlength="10" />
                  <div class="invalid-feedback">Please enter your address (min 10 characters).</div>
                </div>
              </div>
            </div>

            <!-- Row 2: Name | Father Name | Incident Date | Incident Location -->
            <div class="row g-3 form-row-animated" style="--delay:0.1s">
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-user label-icon"></i>Name <span class="req">*</span></span>
                    <span class="lbl-ur">نام</span>
                  </div>
                  <input type="text" class="form-control icp-input" id="person_name" name="person_name"
                    placeholder="Full Name" required minlength="3" />
                  <div class="invalid-feedback">Please enter your name.</div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-user-friends label-icon"></i>Father Name <span class="req">*</span></span>
                    <span class="lbl-ur">والدین/سرپرست کا نام</span>
                  </div>
                  <input type="text" class="form-control icp-input" id="father_name" name="father_name"
                    placeholder="Father/Guardian Name" required minlength="3" />
                  <div class="invalid-feedback">Please enter father/guardian name.</div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-calendar-alt label-icon"></i>Incident Date <span class="req">*</span></span>
                    <span class="lbl-ur">تاریخ واقعہ</span>
                  </div>
                  <input type="date" class="form-control icp-input" id="incident_date" name="incident_date" required />
                  <div class="invalid-feedback">Please select incident date.</div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-location-dot label-icon"></i>Incident Location <span class="req">*</span></span>
                    <span class="lbl-ur">جائے واقعہ</span>
                  </div>
                  <input type="text" class="form-control icp-input" id="incident_location" name="incident_location"
                    placeholder="Incident Location" required minlength="5" />
                  <div class="invalid-feedback">Please enter incident location.</div>
                </div>
              </div>
            </div>

            <!-- Row 3: CNIC | Gender | Nature of Complaint | Country -->
            <div class="row g-3 form-row-animated" style="--delay:0.15s">
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-id-card label-icon"></i>CNIC/Passport <span class="req">*</span></span>
                    <span class="lbl-ur">شناختی کارڈ/پاسپورٹ نمبر</span>
                  </div>
                  <input type="text" class="form-control icp-input" id="person_cnic" name="person_cnic"
                    placeholder="XXXXX-XXXXXXX-X" required maxlength="15" />
                  <div class="invalid-feedback" id="cnicError">Enter valid CNIC (XXXXX-XXXXXXX-X).</div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-venus-mars label-icon"></i>Gender <span class="req">*</span></span>
                    <span class="lbl-ur">جنس</span>
                  </div>
                  <select class="form-control icp-select" id="gender_id" name="gender_id" required>
                    <option value="">Please select your Gender</option>
                  </select>
                  <div class="invalid-feedback">Please select gender.</div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-list-ul label-icon"></i>Nature of Complaint <span class="req">*</span></span>
                    <span class="lbl-ur">شکایت کی نوعیت</span>
                  </div>
                  <select class="form-control icp-select" id="n_complaint_id" name="n_complaint_id" required>
                    <option value="">Select nature of complaint</option>
                  </select>
                  <div class="invalid-feedback">Please select complaint nature.</div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-globe label-icon"></i>Complainant Country <span class="req">*</span></span>
                    <span class="lbl-ur">شکایت کنندہ کی شہریت</span>
                  </div>
                  <select class="form-control icp-select" id="com_country_id" name="com_country_id" required>
                    <option value="" selected>Select Country</option>
                  </select>
                  <div class="invalid-feedback">Please select country.</div>
                </div>
              </div>
            </div>

            <!-- Row 4: Contact | WhatsApp | FIR No | FIR Police Station -->
            <div class="row g-3 form-row-animated" style="--delay:0.2s">
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-phone label-icon"></i>Contact No <span class="req">*</span></span>
                    <span class="lbl-ur">فون نمبر</span>
                  </div>
                  <input type="tel" class="form-control icp-input" id="person_contact" name="person_contact"
                    placeholder="+92-XXX-XXXXXXX" required />
                  <div class="invalid-feedback" id="contactError">Enter valid phone number.</div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fab fa-whatsapp label-icon"></i>WhatsApp No</span>
                    <span class="lbl-ur">واٹس ایپ نمبر</span>
                  </div>
                  <input type="tel" class="form-control icp-input" id="person_whatsapp" name="person_whatsapp"
                    placeholder="WhatsApp No" />
                  <div class="invalid-feedback" id="whatsappError">Enter valid WhatsApp number.</div>
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-file-invoice label-icon"></i>FIR No</span>
                    <span class="lbl-ur">ایف آئی آر نمبر</span>
                  </div>
                  <input type="text" class="form-control icp-input" id="FIR_no" name="FIR_no"
                    placeholder="xxxx/xxxx" />
                </div>
              </div>
              <div class="col-md-3 col-sm-6">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-building-shield label-icon"></i>FIR Police Station</span>
                    <span class="lbl-ur">ایف آئی آر کا تھانہ</span>
                  </div>
                  <select class="form-control icp-select" id="FIR_ps_id" name="FIR_ps_id">
                    <option value="" selected>Select FIR Police Station</option>
                  </select>
                </div>
              </div>
            </div>

            <!-- Row 5: Incident Details -->
            <div class="row g-3 form-row-animated" style="--delay:0.25s">
              <div class="col-12">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-align-left label-icon"></i>Incident details <span class="req">*</span></span>
                    <span class="lbl-ur">واقعہ کی تفصیل</span>
                  </div>
                  <textarea class="form-control icp-input icp-textarea" id="incident_details" name="incident_details"
                    rows="5" placeholder="Enter your complaint details *" required minlength="30"></textarea>
                  <div class="invalid-feedback">Please provide incident details (min 30 characters).</div>
                  <div class="char-counter"><span id="charCount">0</span> / 1000 characters</div>
                </div>
              </div>
            </div>

            <!-- Row 6: File Upload -->
            <div class="row g-3 form-row-animated" style="--delay:0.3s">
              <div class="col-12">
                <div class="field-wrap">
                  <div class="bilingual-label">
                    <span class="lbl-en"><i class="fas fa-paperclip label-icon"></i>Attach Evidence</span>
                    <span class="lbl-ur">ثبوت منسلک کریں</span>
                  </div>
                  <div class="upload-zone" id="uploadZone">
                    <input type="file" id="evidenceFile" name="evidenceFile"
                      accept=".pdf,.jpg,.jpeg,.png" class="upload-input" />
                    <div class="upload-placeholder" id="uploadPlaceholder">
                      <i class="fas fa-cloud-upload-alt upload-icon"></i>
                      <p class="upload-text">Click to choose file or drag & drop here</p>
                      <p class="upload-hint">Supports: PDF, JPG, PNG (Max 5MB)</p>
                    </div>
                    <div class="upload-preview" id="uploadPreview" style="display:none;">
                      <i class="fas fa-file-check upload-icon text-success"></i>
                      <span id="uploadFileName"></span>
                      <button type="button" class="btn-remove-file" id="removeFile"><i class="fas fa-times"></i></button>
                    </div>
                  </div>
                  <div class="invalid-feedback d-block" id="fileError" style="display:none!important;"></div>
                </div>
              </div>
            </div>

            <!-- Row 7: Declaration -->
            <div class="row g-3 form-row-animated" style="--delay:0.35s">
              <div class="col-12">
                <div class="declaration-box">
                  <div class="form-check d-flex align-items-start gap-2">
                    <input class="form-check-input declaration-check" type="checkbox" id="declaration" name="declaration" required />
                    <label class="form-check-label declaration-label" for="declaration">
                      <strong>I do hereby solemnly affirm:</strong>
                      <ol class="declaration-list mt-1">
                        <li>That the facts mentioned in this complaint are correct to the best of my knowledge and belief.</li>
                        <li>That no complaint on this subject has previously been lodged with Agency by me, or on my behalf.</li>
                      </ol>
                    </label>
                  </div>
                  <div class="invalid-feedback declaration-feedback">You must agree to the declaration before submitting.</div>
                </div>
              </div>
            </div>

            <!-- Row 8: Submit Button -->
            <div class="row g-3 form-row-animated" style="--delay:0.4s">
              <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn-register" id="registerBtn">
                  <span class="btn-text">
                    <i class="fas fa-paper-plane me-2"></i>Register
                  </span>
                  <span class="btn-loading" style="display:none;">
                    <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                    Submitting...
                  </span>
                </button>
              </div>
            </div>

          </form>
        </div>
      </section>

    </div><!-- /split-container -->
  </main>

  <!-- ===== CHECK COMPLAINT STATUS MODAL ===== -->
  <div class="modal fade" id="checkStatusModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-info text-white">
          <h5 class="modal-title"><i class="fas fa-search me-2"></i>Check Complaint Status</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <p class="text-muted mb-4">Enter either your Complaint ID or E-tag Number to check the status:</p>
          
          <div class="mb-3">
            <label for="searchComplaintId" class="form-label"><i class="fas fa-id-card me-2"></i>Complaint ID</label>
            <input type="text" class="form-control" id="searchComplaintId" placeholder="Enter Complaint ID">
          </div>

          <div class="d-flex align-items-center mb-3">
            <div style="flex: 1; height: 1px; background: #ddd;"></div>
            <span class="px-3 text-muted">OR</span>
            <div style="flex: 1; height: 1px; background: #ddd;"></div>
          </div>

          <div class="mb-3">
            <label for="searchETag" class="form-label"><i class="fas fa-barcode me-2"></i>E-tag Number</label>
            <input type="text" class="form-control" id="searchETag" placeholder="Enter E-tag Number">
          </div>

          <div id="statusResult" style="display: none;" class="alert alert-info mt-4">
            <div class="mb-3">
              <h6 class="mb-3" id="resultHeading" style="color: #0c63e4; font-weight: 600;"></h6>
              <!-- <p class="mb-2"><strong>Full Name:</strong> <span id="resultName"></span></p>
              <p class="mb-2"><strong>Father Name:</strong> <span id="resultFatherName"></span></p>
              <p class="mb-2"><strong>CNIC:</strong> <span id="resultCNIC"></span></p> -->
              <p id="resultEtagRow" class="mb-2"><strong>E-tag:</strong> <span id="resultETag" style="background: #fff3cd; padding: 4px 8px; border-radius: 4px; font-weight: 600; color: #856404;"></span></p>
              <p class="mb-2"><strong>Status:</strong> <span id="resultStatus" class="badge bg-warning"></span></p>
              <!-- <p class="mb-0"><strong>Assigned To:</strong> <span id="resultMarkTo"></span></p> -->
            </div>
          </div>

          <div id="statusError" style="display: none;" class="alert alert-danger mt-4"></div>

          <div id="statusLoading" style="display: none;" class="text-center">
            <div class="spinner-border text-info" role="status">
              <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2 text-muted">Fetching your complaint status...</p>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-info" id="searchBtn"><i class="fas fa-search me-2"></i>Search</button>
        </div>
      </div>
    </div>
  </div>

  <!-- ===== UPDATE COMPLAINT STATUS MODAL ===== -->
  <div class="modal fade" id="updateStatusModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-warning text-white">
          <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Update Complaint Status</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <form id="updateStatusForm">
            <input type="hidden" id="updateComplaintId">
            
            <div class="mb-3">
              <label for="updateETag" class="form-label"><i class="fas fa-barcode me-2"></i>E-tag Number</label>
              <input type="text" class="form-control" id="updateETag" placeholder="Enter E-tag Number">
              <small class="text-muted">Leave empty if not applicable</small>
            </div>

            <div class="mb-3">
              <label for="updateETagStatus" class="form-label"><i class="fas fa-flag me-2"></i>E-tag Status</label>
              <select class="form-control" id="updateETagStatus" required>
                <option value="Pending">Pending</option>
                <option value="Completed">Completed</option>
                <option value="Filed">Filed</option>
              </select>
            </div>

            <div class="mb-3">
              <label for="updateMarkTo" class="form-label"><i class="fas fa-user-tie me-2"></i>Assigned To</label>
              <input type="text" class="form-control" id="updateMarkTo" placeholder="e.g., Officer Name or Department">
              <small class="text-muted">Who is responsible for this complaint</small>
            </div>

            <div id="updateSuccess" style="display: none;" class="alert alert-success mt-3">
              <i class="fas fa-check-circle me-2"></i>Status updated successfully!
            </div>

            <div id="updateError" style="display: none;" class="alert alert-danger mt-3"></div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-warning" id="updateStatusSaveBtn">
            <i class="fas fa-save me-2"></i>Save Changes
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- ===== CAPTCHA VERIFICATION MODAL ===== -->
  <div class="modal fade" id="captchaModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title"><i class="fas fa-shield-alt me-2"></i>Verify You Are Human</h5>
        </div>
        <div class="modal-body text-center p-4">
          <p class="mb-3">Please solve this simple math problem to confirm you are not a bot:</p>
          <div class="captcha-equation" id="captchaEquation" style="font-size: 28px; font-weight: bold; color: #1976d2; margin: 20px 0; padding: 20px; background: #f5f5f5; border-radius: 8px;">
            <!-- Equation will be inserted here -->
          </div>
          <div class="form-group">
            <input type="text" class="form-control form-control-lg" id="captchaAnswer" placeholder="Enter your answer" maxlength="10" style="text-align: center; font-size: 18px;" />
            <small class="text-muted d-block mt-2">Enter only the number (e.g., 15)</small>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" id="captchaCancel">Cancel</button>
          <button type="button" class="btn btn-primary" id="captchaVerify"><i class="fas fa-check me-2"></i>Verify & Submit</button>
        </div>
      </div>
    </div>
  </div>

  <!-- ===== SUCCESS MODAL ===== -->
  <div class="modal fade" id="successModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content success-modal-content">
        <div class="modal-body text-center p-5">
          <div class="success-icon-wrap mb-4">
            <svg width="80" height="80" viewBox="0 0 80 80">
              <circle cx="40" cy="40" r="38" fill="url(#successGrad)" stroke="#27ae60" stroke-width="2" />
              <polyline points="20,42 34,56 60,26" stroke="white" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round" />
              <defs>
                <linearGradient id="successGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stop-color="#2ecc71" />
                  <stop offset="100%" stop-color="#27ae60" />
                </linearGradient>
              </defs>
            </svg>
          </div>
          <h4 class="success-title">Complaint Registered!</h4>
          <p class="success-subtitle">آپ کی شکایت کامیابی سے درج ہو گئی ہے</p>
          <p class="success-body">Your complaint has been successfully submitted. You will receive a confirmation shortly.</p>
          <div class="complaint-id-box" id="complaintIdBox"></div>
          <button type="button" class="btn-register mt-4" data-bs-dismiss="modal">
            <i class="fas fa-check me-2"></i>Done
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Custom JS -->
  <script src="script.js"></script>
</body>

</html>