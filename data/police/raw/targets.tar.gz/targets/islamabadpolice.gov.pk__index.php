<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Islamabad Capital Territory Police | Official Website</title>
    <meta name="description" content="ICT Police – Online/Walk-in Services, Locate PS/PKM Near Me, Apps, Divisions, Initiatives. Emergency: 15 | Safe City Coverage 90%">

    <!-- Libraries -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Almarai:wght@400;700&family=Cormorant+Garamond:ital,wght@0,500;0,600;1,600&family=Inter:wght@400;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    
    <style>
        :root { --primary: #003087; --gold: #D4AF37; --dark: #0f172a; --light: #f8f9fa; --white: #ffffff; }
        body { font-family: 'Inter', sans-serif; line-height: 1.6; }
        .top-bar { padding: 0; font-size: 0.88rem; }
        .navbar { background: var(--primary); box-shadow: 0 4px 20px rgba(0,0,0,0.1); transition: all 0.3s; color: #fff; }
        .navbar.sticky { position: fixed; top: 0; width: 100%; z-index: 1000; }
        .navbar .nav-link { transition: color 0.3s; color: #fff; }
        .navbar .nav-link:hover { color: var(--gold) !important; }
        .dropdown-menu { animation: fadeIn 0.3s ease-in-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .hero-slider .swiper-slide { height: 100%; position: relative; }
        .hero-slider video, .hero-slider img { width: 100%; height: 100%; object-fit: cover; filter: brightness(0.8); transition: filter 0.5s; }
        .hero-slider .swiper-slide:hover video, .hero-slider .swiper-slide:hover img { filter: brightness(1); }
        .hero-overlay { position: absolute; inset: 0; background: rgba(0,0,0,0.6); z-index: 1; transition: background 0.5s; }
        .stat-card { background: var(--light); border-radius: 15px; padding: 30px; transition: all 0.3s; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .stat-card:hover { transform: scale(1.05); box-shadow: 0 10px 25px rgba(0,0,0,0.2); }
        .stat-icon { font-size: 3rem; color: var(--primary); }
        .service-card { transition: all 0.3s ease; box-shadow: 0 5px 15px rgba(0,0,0,0.1); border: none; animation: cardPulse 2s infinite alternate; }
        @keyframes cardPulse { 0% { transform: scale(1); } 100% { transform: scale(1.02); } }
        .service-card:hover { transform: translateY(-10px) scale(1.05); box-shadow: 0 15px 30px rgba(0,0,0,0.2); animation: none; }
        .map-container { height: 500px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); animation: mapGlow 3s infinite alternate; }
        @keyframes mapGlow { 0% { box-shadow: 0 5px 20px rgba(0,0,0,0.1); } 100% { box-shadow: 0 5px 30px rgba(0,0,0,0.2); } }
        .search-input { border: 2px solid var(--primary); border-radius: 30px; padding: 12px 25px; font-size: 1.1rem; transition: border-color 0.3s; }
        .search-input:focus { border-color: var(--gold); }
        .social-icons a { width: 50px; height: 50px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin: 0 8px; transition: all 0.3s; box-shadow: 0 5px 15px rgba(0,0,0,0.2); animation: socialBounce 1.5s infinite; }
        @keyframes socialBounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
        .social-icons a:hover { animation: none; transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.3); }
        .emergency-chat-container { position: fixed; bottom: 30px; right: 30px; z-index: 9999; }
        .main-float-btn { width: 60px; height: 60px; border-radius: 50%; background: var(--primary); color: white; font-size: 1.5rem; box-shadow: 0 5px 15px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.3s; }
        .main-float-btn:hover { background: var(--gold); }
        .sub-btn { width: 50px; height: 50px; border-radius: 50%; color: white; font-size: 1.2rem; box-shadow: 0 5px 15px rgba(0,0,0,0.2); display: flex; align-items: center; justify-content: center; text-decoration: none; position: absolute; right: 5px; transition: all 0.3s; opacity: 0; visibility: hidden; }
        .sub-btn.emergency { background: #dc3545; top: -60px; }
        .sub-btn.chat { background: #28a745; top: -120px; }
        .emergency-chat-container.open .sub-btn { opacity: 1; visibility: visible; top: auto; animation: slideDown 0.3s ease-out; }
        @keyframes slideDown { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .left-helplines { position: fixed; bottom: 30px; left: 30px; z-index: 9999; }
        .helpline-main { width: 60px; height: 60px; border-radius: 50%; background: var(--primary); color: white; font-size: 1.5rem; box-shadow: 0 5px 15px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.3s; }
        .helpline-main:hover { background: var(--gold); }
        .helpline-sub { width: 50px; height: 50px; border-radius: 50%; color: white; font-size: 1.2rem; box-shadow: 0 5px 15px rgba(0,0,0,0.2); display: flex; align-items: center; justify-content: center; text-decoration: none; position: absolute; left: 5px; transition: all 0.3s; opacity: 0; visibility: hidden; }
        .helpline-sub.women { background: #ff69b4; top: -60px; }
        .helpline-sub.igp { background: #28a745; top: -120px; }
        .helpline-sub.itp { background: #007bff; top: -180px; }
        .left-helplines.open .helpline-sub { opacity: 1; visibility: visible; top: auto; animation: slideDown 0.3s ease-out; }
        footer { background: var(--dark); color: white; padding: 50px 0; }
        .footer-link { color: #ccc; transition: color 0.3s; }
        .footer-link:hover { color: var(--gold); }
        .footer-section { border-right: 1px solid #333; }
        .footer-section:last-child { border-right: none; }
        .section-online { background: #e3f2fd; } /* Light blue for online */
        .section-apps { background: #e8f5e9; } /* Light green for apps */
        .section-walkin { background: #fff3e0; } /* Light orange for walk-in */
        .section-divisions { background: #f3e5f5; } /* Light purple for divisions */
        .section-locator { background: #e0f7fa; } /* Light cyan for locator */
        .section-media { background: #fce4ec; } /* Light pink for media */
    </style>
    <link rel="stylesheet" href="assets/css/responsive.css">
    <link rel="stylesheet" href="assets/css/homepage-responsive.css">

</head>
<body>
    <div class="helplines-sidebar" id="helplinesSidebar" aria-label="Emergency helplines">
    <a href="tel:15" class="helpline-btn pucar" data-helpline>
        <i class="fas fa-phone-volume" aria-hidden="true"></i>
        <span>Emergency 15</span>
    </a>
    <a href="tel:1815" class="helpline-btn women" data-helpline>
        <i class="fas fa-female" aria-hidden="true"></i>
        <span>Online Women PS 1815</span>
    </a>
    <a href="tel:1715" class="helpline-btn igp" data-helpline>
        <i class="fas fa-shield" aria-hidden="true"></i>
        <span>IGP Complaint Cell 1715</span>
    </a>
    <a href="tel:1915" class="helpline-btn itp" data-helpline>
        <i class="fas fa-car" aria-hidden="true"></i>
        <span>Traffic Helpline 1915</span>
    </a>
</div>

<style>
.helplines-sidebar {
    position: fixed;
    top: 50%;
    left: 0;
    transform: translateY(-50%);
    display: flex;
    flex-direction: column;
    gap: 6px;
    z-index: 9998;
    padding: 8px 0;
    max-width: calc(100vw - 12px);
}

.helpline-btn {
    display: flex;
    align-items: center;
    width: 42px;
    height: 42px;
    background: #003087;
    color: #fff;
    font-size: 1rem;
    text-decoration: none;
    transition: width 0.28s ease, background 0.28s ease, box-shadow 0.28s ease;
    overflow: hidden;
    white-space: nowrap;
    border-top-right-radius: 21px;
    border-bottom-right-radius: 21px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.22);
    -webkit-tap-highlight-color: transparent;
    touch-action: manipulation;
}

.helpline-btn i {
    flex: 0 0 42px;
    width: 42px;
    text-align: center;
    line-height: 42px;
}

.helpline-btn span {
    opacity: 0;
    max-width: 0;
    overflow: hidden;
    transition: opacity 0.22s ease, max-width 0.28s ease;
    padding-right: 0;
    font-weight: 600;
    font-size: 0.88rem;
}

.helpline-btn.is-expanded,
.helplines-sidebar.has-expanded .helpline-btn.is-expanded {
    width: min(248px, calc(100vw - 20px));
    box-shadow: 0 4px 14px rgba(0, 0, 0, 0.28);
}

.helpline-btn.is-expanded span,
.helplines-sidebar.has-expanded .helpline-btn.is-expanded span {
    opacity: 1;
    max-width: 200px;
    padding-right: 14px;
}

@media (hover: hover) and (pointer: fine) {
    .helpline-btn:hover {
        width: min(248px, calc(100vw - 20px));
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.28);
    }

    .helpline-btn:hover span {
        opacity: 1;
        max-width: 200px;
        padding-right: 14px;
    }
}

.pucar { background: #bb333b; }
.pucar:hover,
.pucar.is-expanded { background: #c93d45; }
.women { background: #ff69b4; }
.women:hover,
.women.is-expanded { background: #ff4d9f; }
.igp { background: #28a745; }
.igp:hover,
.igp.is-expanded { background: #218838; }
.itp { background: #007bff; }
.itp:hover,
.itp.is-expanded { background: #0069d9; }

@media (max-width: 575.98px) {
    .helplines-sidebar {
        top: 50%;
        left: 0;
        bottom: auto;
        right: auto;
        transform: translateY(-50%);
    }

    .helpline-btn {
        width: 40px;
        height: 40px;
    }

    .helpline-btn i {
        flex: 0 0 40px;
        width: 40px;
        line-height: 40px;
        font-size: 0.95rem;
    }

    .helpline-btn.is-expanded,
    .helplines-sidebar.has-expanded .helpline-btn.is-expanded {
        width: min(260px, calc(100vw - 16px));
    }

    .helpline-btn span {
        font-size: 0.82rem;
    }
}
</style>

<script>
(function () {
    var sidebar = document.getElementById('helplinesSidebar');
    if (!sidebar) return;

    var buttons = sidebar.querySelectorAll('[data-helpline]');

    function needsTwoTap() {
        return window.matchMedia('(hover: none), (pointer: coarse)').matches;
    }

    function collapseAll() {
        buttons.forEach(function (btn) {
            btn.classList.remove('is-expanded');
            btn.removeAttribute('data-expanded');
        });
        sidebar.classList.remove('has-expanded');
    }

    buttons.forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            if (!needsTwoTap()) {
                return;
            }

            if (btn.getAttribute('data-expanded') === '1') {
                collapseAll();
                return;
            }

            e.preventDefault();
            e.stopPropagation();

            buttons.forEach(function (other) {
                if (other !== btn) {
                    other.classList.remove('is-expanded');
                    other.removeAttribute('data-expanded');
                }
            });

            btn.classList.add('is-expanded');
            btn.setAttribute('data-expanded', '1');
            sidebar.classList.add('has-expanded');
        });
    });

    document.addEventListener('click', function (e) {
        if (!sidebar.classList.contains('has-expanded')) {
            return;
        }
        if (sidebar.contains(e.target)) {
            return;
        }
        collapseAll();
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            collapseAll();
        }
    });

    window.addEventListener('resize', function () {
        if (!needsTwoTap()) {
            collapseAll();
        }
    });
})();
</script>
    <style>
.top-bar {
    position: relative;
    background: linear-gradient(105deg, #001f5c 0%, #003087 42%, #004aad 100%);
    border-bottom: 3px solid #D4AF37;
    animation: fadeIn 0.5s ease-in;
    padding: 0.55rem 0;
    overflow: hidden;
}
.top-bar::before {
    content: '';
    position: absolute;
    inset: 0;
    background: radial-gradient(circle at 50% 120%, rgba(212, 175, 55, 0.16) 0%, transparent 58%);
    pointer-events: none;
}
.top-bar-inner {
    position: relative;
    z-index: 1;
}
.top-bar-grid {
    display: grid;
    grid-template-columns: auto 1fr auto;
    align-items: center;
    gap: 1rem;
}
.top-bar-logo {
    display: flex;
    align-items: center;
    justify-self: start;
}
.top-bar-logo a {
    display: inline-flex;
    line-height: 0;
}
.top-bar-logo a:hover .logo-img {
    transform: scale(1.02);
}
.top-bar-center {
    text-align: center;
    justify-self: center;
    width: 100%;
    max-width: 640px;
    margin: 0 auto;
}
.top-bar-tagline {
    line-height: 1.3;
}
.top-bar-dept {
    display: block;
    font-family: 'Playfair Display', Georgia, 'Times New Roman', serif;
    font-size: clamp(0.75rem, 1.65vw, 1.01rem);
    font-weight: 700;
    color: #fff;
    letter-spacing: 0.03em;
    line-height: 1.25;
    text-transform: uppercase;
    text-shadow: 0 2px 12px rgba(0, 0, 0, 0.2);
}
.top-bar-motto {
    display: block;
    font-family: 'Cormorant Garamond', Georgia, serif;
    font-size: clamp(0.79rem, 1.8vw, 1.09rem);
    font-weight: 600;
    font-style: italic;
    color: #f3dfa0;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    margin-top: 0.15rem;
    text-shadow: 0 1px 8px rgba(0, 0, 0, 0.18);
}
.top-bar-motto::before,
.top-bar-motto::after {
    content: '—';
    color: rgba(212, 175, 55, 0.75);
    margin: 0 0.45rem;
    font-style: normal;
    font-weight: 500;
}
.top-bar-helplines {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    justify-self: end;
}
.logo-img {
    height: 72px;
    width: auto;
    filter: drop-shadow(0 3px 10px rgba(0, 0, 0, 0.28));
    transition: transform 0.3s ease;
}
.helpline-chip.emergency {
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    padding: 0.48rem 1rem;
    border-radius: 999px;
    font-family: 'Inter', sans-serif;
    font-size: 0.88rem;
    font-weight: 700;
    text-decoration: none;
    color: #fff;
    background: linear-gradient(135deg, #dc2626, #b91c1c);
    border: 1px solid rgba(255, 255, 255, 0.35);
    box-shadow: 0 4px 14px rgba(220, 38, 38, 0.35);
    animation: emergencyPulse 2s infinite;
    white-space: nowrap;
    transition: transform 0.25s ease, background 0.25s ease;
}
.helpline-chip.emergency i {
    font-size: 0.9rem;
}
.helpline-chip.emergency span.num {
    color: #fff7d6;
    font-weight: 800;
    letter-spacing: 0.05em;
}
.helpline-chip.emergency:hover {
    transform: translateY(-2px);
    background: linear-gradient(135deg, #ef4444, #dc2626);
    color: #fff;
}
@keyframes emergencyPulse {
    0% { box-shadow: 0 4px 14px rgba(220, 38, 38, 0.35), 0 0 0 0 rgba(220, 38, 38, 0.5); }
    70% { box-shadow: 0 4px 14px rgba(220, 38, 38, 0.35), 0 0 0 8px rgba(220, 38, 38, 0); }
    100% { box-shadow: 0 4px 14px rgba(220, 38, 38, 0.35), 0 0 0 0 rgba(220, 38, 38, 0); }
}
@media (max-width: 991.98px) {
    .top-bar-grid {
        grid-template-columns: auto 1fr;
        grid-template-areas:
            "logo emergency"
            "center center";
        gap: 0.65rem 1rem;
    }
    .top-bar-logo { grid-area: logo; }
    .top-bar-center { grid-area: center; }
    .top-bar-helplines {
        grid-area: emergency;
        justify-content: flex-end;
    }
}
@media (max-width: 575.98px) {
    .logo-img {
        height: 54px;
    }
    .top-bar-motto {
        letter-spacing: 0.06em;
    }
    .top-bar-motto::before,
    .top-bar-motto::after {
        margin: 0 0.3rem;
    }
}
</style>

<div class="top-bar">
    <div class="container top-bar-inner py-2">
        <div class="top-bar-grid">
            <div class="top-bar-logo">
                <a href="index.php">
                    <img src="assets/images/Capital_Territory_Police.png" alt="ICT Police" class="logo-img">
                </a>
            </div>

            <div class="top-bar-center">
                <div class="top-bar-tagline">
                    <span class="top-bar-dept">Islamabad Capital Territory Police</span>
                    <span class="top-bar-motto">Service With Passion</span>
                </div>
            </div>

            <div class="top-bar-helplines">
                                <a href="tel:15" class="helpline-chip emergency">
                    <i class="fas fa-phone-volume"></i>
                    <span>Emergency</span>
                    <span class="num">15</span>
                </a>
            </div>
        </div>
    </div>
</div>
    <!-- Sticky Navbar -->
<style>
.navbar {
    background: #0c315d;
    border-bottom: 1px solid #fff;
    border-top: 1px solid #fff;
}
.navbar-nav .nav-link {
    color: #fff !important;
    font-weight: 500;
    transition: all 0.3s ease;
}
.navbar-nav .nav-link:hover {
    color: #D4AF37 !important;
}
.dropdown-menu {
    background: #1e3a8a;
    border: none;
    border-radius: 8px;
}
.dropdown-item {
    color: #fff !important;
    font-weight: 400;
}
.dropdown-item:hover {
    background: #D4AF37;
    color: #000 !important;
}
</style>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMain">
            <ul class="navbar-nav w-100 d-flex flex-lg-row justify-content-lg-around fw-semibold">
                                <li class="nav-item ">
                    <a class="nav-link " 
                       href="index.php" 
                       >
                                                    <i class="fas fa-home me-2"></i>
                                                Home                    </a>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="#" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-shield me-2"></i>
                                                About Us                    </a>
                                        <ul class="dropdown-menu">
                                                                        <li>
                            <a class="dropdown-item" href="about.php">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                About ICTP                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="vision.php">
                                                                    <i class="fas fa-receipt me-2"></i>
                                                                Our Vision &amp; Mission                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="igp-message.php">
                                                                    <i class="fas fa-id-card me-2"></i>
                                                                IGP Message                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="officers.php">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Officers of Islamabad Police                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="organ.php">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Organogram                            </a>
                        </li>
                                                                    </ul>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="#" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-laptop me-2"></i>
                                                Services                    </a>
                                        <ul class="dropdown-menu">
                                                                            <li>
                            <a class="dropdown-item" href="https://soft.islamabadpolice.gov.pk/appointment/" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-book me-2"></i>
                                                                Book Online Appointment                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-cc.php">
                                                                    <i class="fas fa-id-card me-2"></i>
                                                                Character Certificate                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-gv.php">
                                                                    <i class="fas fa-check me-2"></i>
                                                                General Police Verification                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-tr.php">
                                                                    <i class="fas fa-home me-2"></i>
                                                                Tenant Registration                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-sr.php">
                                                                    <i class="fas fa-user me-2"></i>
                                                                Servant Registration                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-fr.php">
                                                                    <i class="fas fa-globe me-2"></i>
                                                                Foreigner Registration                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://dlims.islamabadpolice.gov.pk/" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-id-card-alt me-2"></i>
                                                                Driving License Renewal                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://dlims.islamabadpolice.gov.pk/" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-id-card-alt me-2"></i>
                                                                Online Learner Permit                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://traffic.islamabadpolice.gov.pk/Echallan" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-receipt me-2"></i>
                                                                E-Challan Verification                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://dlims.islamabadpolice.gov.pk/" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-id-card-alt me-2"></i>
                                                                Driving License Verification                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-fir.php">
                                                                    <i class="fas fa-copy me-2"></i>
                                                                Copy of FIR                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="srv-lr.php">
                                                                    <i class="fas fa-file-alt me-2"></i>
                                                                Lost Report                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://islamabadpolice.gov.pk/fms/complaints.php" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-comment-dots me-2"></i>
                                                                Report an Incident                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://islamabadpolice.gov.pk/fms/" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-book me-2"></i>
                                                                Give Feedback                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="facilitation-on-wheels.php">
                                                                    <i class="fas fa-bus me-2"></i>
                                                                Facilitation On Wheels                            </a>
                        </li>
                                                    <li>
                            <a class="dropdown-item" href="https://soft.islamabadpolice.gov.pk/tvs/login" target="_blank" rel="noopener noreferrer">
                                                                    <i class="fas fa-car me-2"></i>
                                                                Taxi Verification System                            </a>
                        </li>
                                                                        </ul>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="heros.php" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-medal me-2"></i>
                                                Our Heroes                    </a>
                                        <ul class="dropdown-menu">
                                                                        <li>
                            <a class="dropdown-item" href="heros.php">
                                                                    <i class="fas fa-moon me-2"></i>
                                                                Our Martyrs                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="ghazis.php">
                                                                    <i class="fas fa-medal me-2"></i>
                                                                Our Ghazis                            </a>
                        </li>
                                                                    </ul>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="#" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-lightbulb me-2"></i>
                                                Initiatives                    </a>
                                        <ul class="dropdown-menu">
                                                                        <li>
                            <a class="dropdown-item" href="initiatives.php?slug=-nline-omen-olice-tation">
                                                                Online Women Police Station                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="initiatives.php?slug=-acilitation-on-wheels">
                                                                Facilitation On Wheels                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="initiatives.php?slug=-olice-tation-n-heels">
                                                                Police Station (PS) On Wheels                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="initiatives.php?slug=-mergency-elplines">
                                                                Emergency Helplines                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="initiatives.php?slug=-ssential-afety-ips-for-itizens">
                                                                Essential Safety Tips for Citizens                            </a>
                        </li>
                                                                    </ul>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="#" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-building me-2"></i>
                                                Divisions                    </a>
                                        <ul class="dropdown-menu">
                                                                        <li>
                            <a class="dropdown-item" href="division.php?slug=safe-city-islamabad">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Safe City Islamabad                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=operations-division">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Operations Division                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=law-order-and-training-division">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Law &amp; Order and Training Division                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=security-division">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Security Division                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=headquarters-logistics-division">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Headquarters &amp; Logistics Division                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=islamabad-traffic-police">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Islamabad Traffic Police (ITP)                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=ctd">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Counter Terrorism Department (CTD)                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="division.php?slug=special-branch">
                                                                    <i class="fas fa-shield me-2"></i>
                                                                Special Branch Islamabad Police                            </a>
                        </li>
                                                                    </ul>
                                    </li>
                                <li class="nav-item ">
                    <a class="nav-link " 
                       href="media.php" 
                       >
                                                    <i class="fas fa-hands-helping me-2"></i>
                                                Media                    </a>
                                    </li>
                                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" 
                       href="#" 
                       data-bs-toggle="dropdown">
                                                    <i class="fas fa-bullhorn me-2"></i>
                                                Notices                    </a>
                                        <ul class="dropdown-menu">
                                                                        <li>
                            <a class="dropdown-item" href="tender.php">
                                                                    <i class="fas fa-file-contract me-2"></i>
                                                                Tender                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="auction.php">
                                                                    <i class="fas fa-gavel me-2"></i>
                                                                Auctions                            </a>
                        </li>
                                                <li>
                            <a class="dropdown-item" href="job.php">
                                                                    <i class="fas fa-briefcase me-2"></i>
                                                                Jobs                            </a>
                        </li>
                                                                    </ul>
                                    </li>
                                <li class="nav-item ">
                    <a class="nav-link " 
                       href="contact.php" 
                       >
                                                    <i class="fas fa-envelope me-2"></i>
                                                Contact                    </a>
                                    </li>
                            </ul>
        </div>
    </div>
</nav>
    <!-- Dynamic Hero Slider - ONE Background Video + Dynamic Text -->
<section class="hero-section position-relative overflow-hidden">
    
    <!-- Background Video -->
    <video autoplay muted loop playsinline class="hero-video">
        <source src="assets/videos/ictpolice.mp4" type="video/mp4">
        Your browser does not support video.
    </video>

    <!-- Dark Overlay -->
    <div class="hero-overlay"></div>

    <!-- Swiper Slider -->
    <div class="swiper hero-slider">
        <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                        <div class="hero-content">
                            <h1 class="title">Safe City Islamabad</h1>
                                                            <p class="subtitle">24/7 Digital Security for the Capital</p>
                                                        <a href="#locator" class="hero-btn">
                                Find Nearest PS/PKM                            </a>
                        </div>
                    </div>
                                    <div class="swiper-slide">
                        <div class="hero-content">
                            <h1 class="title">Innovation in Policing  Trust in Service</h1>
                                                        <a href="https://pwm.islamabadpolice.gov.pk/islamabad-police-2025/about.php" class="hero-btn">
                                About Us                            </a>
                        </div>
                    </div>
                                    <div class="swiper-slide">
                        <div class="hero-content">
                            <h1 class="title">Mobile Apps</h1>
                                                            <p class="subtitle">Vigilance, Safety, and Public Support</p>
                                                        <a href="#mobile-apps" class="hero-btn">
                                Download Now                            </a>
                        </div>
                    </div>
                                    </div>
        <div class="swiper-pagination"></div>
    </div>
</section>

<style>
.hero-section {
    height: 70vh;
    position: relative;
}
.hero-video {
    position: absolute;
    top: 0; left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    z-index: 1;
}
.hero-overlay {
    position: absolute;
    top: 0; left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.55);
    z-index: 2;
}
.hero-slider {
    position: relative;
    z-index: 3;
    height: 100%;
    
}
.swiper-slide {
    display: flex;
    align-items: center;
    justify-content: center;
}
.hero-content {
    text-align: center;
    max-width: 900px;
    padding: 2rem;
    background: rgba(0, 0, 0, 0.14);
    z-index: 2;
    border-radius: 50px;
    opacity: 0;
    transform: translateX(80px);
}
.hero-content.is-visible {
    animation: heroSlideInRTL 0.85s ease-out forwards;
}
@keyframes heroSlideInRTL {
    from {
        opacity: 0;
        transform: translateX(80px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}
.title {
    font-size: 3.5rem;
    font-weight: 800;
    color: #D4AF37;
    text-shadow: 4px 4px 15px rgba(0,0,0,0.9);
    margin-bottom: 1.5rem;
}
.subtitle {
    font-size: 2.2rem;
    color: #fff;
    text-shadow: 3px 3px 12px rgba(0,0,0,0.9);
    margin-bottom: 2.5rem;
}
.hero-btn {
    background: linear-gradient(45deg, #D4AF37, #FFD700);
    color: black;
    font-weight: 700;
    font-size: 1.4rem;
    padding: 15px 15px;
    border-radius: 50px;
    text-decoration: none;
    display: inline-block;
    box-shadow: 0 10px 30px rgba(212, 175, 55, 0.5);
    transition: all 0.4s ease;
}
.hero-btn:hover {
    background: linear-gradient(45deg, #FFD700, #FFA500);
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(255, 165, 0, 0.6);
    color: black;
}
.swiper-pagination-bullet {
    background: white;
    opacity: 0.7;
    width: 14px;
    height: 14px;
}
.swiper-pagination-bullet-active {
    background: #D4AF37;
    opacity: 1;
}

@media (max-width: 991.98px) {
    .hero-section {
        height: 65vh;
        min-height: 420px;
    }
    .title {
        font-size: 2.4rem;
    }
    .subtitle {
        font-size: 1.35rem;
        margin-bottom: 1.75rem;
    }
}

@media (max-width: 575.98px) {
    .hero-section {
        height: 58vh;
        min-height: 360px;
    }
    .hero-content {
        padding: 1.25rem 1rem;
        border-radius: 24px;
        max-width: 100%;
    }
    .title {
        font-size: 1.75rem;
        margin-bottom: 1rem;
    }
    .subtitle {
        font-size: 1.05rem;
        margin-bottom: 1.25rem;
    }
    .hero-btn {
        font-size: 1rem;
        padding: 12px 18px;
        display: block;
        width: 100%;
        max-width: 280px;
        margin: 0 auto;
    }
}

</style>
    <!-- ICT Police at a Glance - FULLY DYNAMIC & PERFECTLY BALANCED -->
<section class="py-5 bg-light" id="glance">
    <div class="container">
        <h2 class="text-center display-5 fw-bold mb-5 text-primary" data-aos="fade-up">
            ICT Police at a Glance
        </h2>
        <div class="row g-5 align-items-stretch"> <!-- align-items-stretch ensures both columns have equal height -->
            <!-- Left Column: IGP Message -->
            <div class="col-lg-6 d-flex" data-aos="fade-right">
                                <div class="card shadow-lg border-0 w-100 d-flex flex-column">
                    <div class="card-body text-center p-4 flex-grow-1 d-flex flex-column justify-content-between">
                        <div>
                            <div class="igp-photo-wrap mb-4">
                                <img src="assets/images/igp/igp_message_1790069759.jpg"
                                     alt="Captain (R) Muhammad Sohail Chaudhry, PSP"
                                     class="igp-photo shadow-lg"
                                     width="360"
                                     height="240"
                                     loading="lazy"
                                     decoding="async">
                            </div>
                            <h4 class="fw-bold text-primary mb-2">Captain (R) Muhammad Sohail Chaudhry, PSP</h4>
                            <p class="text-muted mb-3">Inspector General of Police (IGP)</p>
                            <hr class="w-75 mx-auto border-primary opacity-50">
                            <p class="lead text-dark mt-4 text-start px-3 igp-excerpt">
                                Islamabad Police is committed to upholding public order and the rule of law through professional, intelligence based, and technology driven policing that responds effectively to the evolving security needs of the federal capital. Through continuous institutional reform, modern policing tools, and investment in human capital, we strive to deliver efficient, transparent, and accountable services aligned with international law enforcement standards. Emphasizing proactive crime prevention, swift response, and community partnership, Islamabad Police works closely with citizens and stakeholders to strengthen trust and ensure the protection of life, liberty, and property, fostering a safe, peaceful, and resilient Islamabad.                            </p>
                        </div>
                                                    <div class="mt-4">
                                <a href="igp-message.php" class="btn btn-outline-primary w-100">
                                    Read Full Message →
                                </a>
                            </div>
                                            </div>
                </div>
            </div>

            <!-- Right Column: Stats (4 small + 1 large) -->
            <div class="col-lg-6 d-flex">
                <div class="w-100 d-flex flex-column">
                    <!-- Top Row: 4 Small Stats (2x2 Grid) -->
                    <div class="row g-4 flex-grow-1">
                                                <div class="col-12 col-sm-6 d-flex" data-aos="fade-up" data-aos-delay="100">
                            <div class="card stat-card text-center p-4 shadow-lg border-0 hover-lift h-100 w-100 d-flex flex-column justify-content-center" style="background:#f0f0f0;">
                                <i class="fas fa-users fa-3x text-primary mb-3"></i>
                                <h2 class="fw-bold display-6 mb-1 text-dark">12,625</h2>
                                <p class="fw-semibold mb-0 text-muted">Dedicated Strength</p>
                            </div>
                        </div>
                                                <div class="col-12 col-sm-6 d-flex" data-aos="fade-up" data-aos-delay="200">
                            <div class="card stat-card text-center p-4 shadow-lg border-0 hover-lift h-100 w-100 d-flex flex-column justify-content-center" style="background:#f0f0f0;">
                                <i class="fas fa-shield-alt fa-3x text-primary mb-3"></i>
                                <h2 class="fw-bold display-6 mb-1 text-dark">75%</h2>
                                <p class="fw-semibold mb-0 text-muted">Safe City Coverage</p>
                            </div>
                        </div>
                                                <div class="col-12 col-sm-6 d-flex" data-aos="fade-up" data-aos-delay="300">
                            <div class="card stat-card text-center p-4 shadow-lg border-0 hover-lift h-100 w-100 d-flex flex-column justify-content-center" style="background:#f0f0f0;">
                                <i class="fas fa-chart-line fa-3x text-primary mb-3"></i>
                                <h2 class="fw-bold display-6 mb-1 text-dark">80%</h2>
                                <p class="fw-semibold mb-0 text-muted">Crime Reduction</p>
                            </div>
                        </div>
                                                <div class="col-12 col-sm-6 d-flex" data-aos="fade-up" data-aos-delay="400">
                            <div class="card stat-card text-center p-4 shadow-lg border-0 hover-lift h-100 w-100 d-flex flex-column justify-content-center" style="background:#f0f0f0;">
                                <i class="fas fa-clock fa-3x text-primary mb-3"></i>
                                <h2 class="fw-bold display-6 mb-1 text-dark">5-7 Min</h2>
                                <p class="fw-semibold mb-0 text-muted">Response Time</p>
                            </div>
                        </div>
                                            </div>

                    <!-- Bottom: Large Stat Card -->
                    <div class="row mt-4">
                        <div class="col-12 d-flex" data-aos="fade-up" data-aos-delay="500">
                                                        <div class="card shadow-lg border-0 text-center p-5 hover-lift bg-gradient-primary text-white h-100 w-100 d-flex flex-column justify-content-center">
                                <h2 class="display-5 fw-bold mb-0">AI Empowered Policing</h2>
                            </div>
                                                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.stat-card {
    transition: all 0.4s ease;
    background: #f8f9fa;
    border-radius: 20px;
    min-height: 200px;
}
.stat-card:hover {
    transform: translateY(-12px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.15) !important;
}
.hover-lift { 
    transition: all 0.4s ease; 
}
.bg-gradient-primary {
    background: linear-gradient(135deg, #003087, #0056b3);
}
.card {
    border-radius: 20px !important;
}
.igp-excerpt {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
    overflow: hidden;
    text-align: justify;
    line-height: 1.6;
    max-height: calc(1.6em * 3);
    margin-bottom: 0;
}
/* Horizontal rectangle — avoid upscaling small organogram photos */
.igp-photo-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
}
.igp-photo {
    width: 100%;
    max-width: 420px;
    height: 260px;
    object-fit: cover;
    object-position: center top;
    border-radius: 12px;
    border: 4px solid #fff;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}
@media (max-width: 768px) {
    .igp-photo {
        max-width: 100%;
        height: 220px;
    }
}
</style>    <!-- Online Services Cards - 100% DYNAMIC & RESPONSIVE -->
<section class="py-5 section-online" id="online-services">
    <div class="container">
        <h2 class="text-center display-5 fw-bold mb-5 text-primary" data-aos="fade-up">
            <i class="fas fa-users me-2"></i>Citizens Services
        </h2>

        <div class="row g-4">
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="0">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-book me-2 text-primary"></i>
                            Book Online Appointment                        </h5>
                        <p class="small text-muted mb-4">Save Your Time and Book an Online Appointment</p>
                        <a href="https://soft.islamabadpolice.gov.pk/appointment/" 
                           class="btn btn-outline-primary mt-auto stretched-link" target="_blank" rel="noopener noreferrer">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-id-card me-2 text-primary"></i>
                            Character Certificate                        </h5>
                        <p class="small text-muted mb-4">character verification required for job, visas &amp; international travel</p>
                        <a href="srv-cc.php" 
                           class="btn btn-outline-primary mt-auto stretched-link">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-check me-2 text-info"></i>
                            General Police Verification                        </h5>
                        <p class="small text-muted mb-4">Police verification service for individuals and official requirements</p>
                        <a href="srv-gv.php" 
                           class="btn btn-outline-info mt-auto stretched-link">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-home me-2 text-success"></i>
                            Tenant Registration                        </h5>
                        <p class="small text-muted mb-4">Registration of tenants for public safety</p>
                        <a href="srv-tr.php" 
                           class="btn btn-outline-success mt-auto stretched-link">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="400">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-user me-2 text-danger"></i>
                            Servant Registration                        </h5>
                        <p class="small text-muted mb-4">Police verification for domestic and private employees</p>
                        <a href="srv-sr.php" 
                           class="btn btn-outline-danger mt-auto stretched-link">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="500">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-globe me-2 text-success"></i>
                            Foreigner Registration                        </h5>
                        <p class="small text-muted mb-4">Assistance related to foreigners’ security matters</p>
                        <a href="srv-fr.php" 
                           class="btn btn-outline-success mt-auto stretched-link">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="600">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-id-card-alt me-2 text-success"></i>
                            Driving License Renewal                        </h5>
                        <p class="small text-muted mb-4">Smart/Biometric (Overseas Portal; Form B)</p>
                        <a href="https://dlims.islamabadpolice.gov.pk/" 
                           class="btn btn-outline-success mt-auto stretched-link" target="_blank" rel="noopener noreferrer">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="700">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-id-card-alt me-2 text-dark"></i>
                            Online Learner Permit                        </h5>
                        <p class="small text-muted mb-4">Digital application facility for learner driving permits</p>
                        <a href="https://dlims.islamabadpolice.gov.pk/" 
                           class="btn btn-outline-dark mt-auto stretched-link" target="_blank" rel="noopener noreferrer">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="800">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-receipt me-2 text-primary"></i>
                            E-Challan Verification                        </h5>
                        <p class="small text-muted mb-4">Check and pay your traffic e-challan online using a secure digital payment system</p>
                        <a href="https://traffic.islamabadpolice.gov.pk/Echallan" 
                           class="btn btn-outline-primary mt-auto stretched-link" target="_blank" rel="noopener noreferrer">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="900">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-id-card-alt me-2 text-warning"></i>
                            Driving License Verification                        </h5>
                        <p class="small text-muted mb-4">Driving License Verification in One Click</p>
                        <a href="https://dlims.islamabadpolice.gov.pk/" 
                           class="btn btn-outline-warning mt-auto stretched-link" target="_blank" rel="noopener noreferrer">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="1000">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-copy me-2 text-danger"></i>
                            Copy of FIR                        </h5>
                        <p class="small text-muted mb-4">Access to an official copy of registered FIR</p>
                        <a href="srv-fir.php" 
                           class="btn btn-outline-danger mt-auto stretched-link">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="1100">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-file-alt me-2 text-warning"></i>
                            Lost Report                        </h5>
                        <p class="small text-muted mb-4">Registration and recovery assistance for lost items</p>
                        <a href="srv-lr.php" 
                           class="btn btn-outline-warning mt-auto stretched-link">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="1200">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-comment-dots me-2 text-primary"></i>
                            Report an Incident                        </h5>
                        <p class="small text-muted mb-4">Submission and processing of general public complaints</p>
                        <a href="https://islamabadpolice.gov.pk/fms/complaints.php" 
                           class="btn btn-outline-primary mt-auto stretched-link" target="_blank" rel="noopener noreferrer">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="1300">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-book me-2 text-primary"></i>
                            Give Feedback                        </h5>
                        <p class="small text-muted mb-4">Give Feedback About Our Services</p>
                        <a href="https://islamabadpolice.gov.pk/fms/" 
                           class="btn btn-outline-primary mt-auto stretched-link" target="_blank" rel="noopener noreferrer">
                            Apply Now                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="1400">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-bus me-2 text-success"></i>
                            Facilitation On Wheels                        </h5>
                        <p class="small text-muted mb-4">Schedule and services available on Facilitation on Wheels — updated regularly.</p>
                        <a href="facilitation-on-wheels.php" 
                           class="btn btn-outline-success mt-auto stretched-link">
                            View Schedule                        </a>
                    </div>
                </div>
                            <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="1500">
                    <div class="card service-card text-center p-4 h-100 shadow-lg border-0 hover-lift">
                        <h5 class="fw-bold mb-3">
                            <i class="fas fa-car me-2 text-primary"></i>
                            Taxi Verification System                        </h5>
                        <p class="small text-muted mb-4">Passengers and Drivers Safety Application</p>
                        <a href="https://soft.islamabadpolice.gov.pk/tvs/login" 
                           class="btn btn-outline-primary mt-auto stretched-link" target="_blank" rel="noopener noreferrer">
                            Apply Now                        </a>
                    </div>
                </div>
                    </div>
    </div>
</section>

<style>
.section-online {
    background: #f8f9fa;
}
.service-card {
    transition: all 0.4s ease;
    border-radius: 20px;
    background: white;
}
.service-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.15) !important;
}
.btn-outline-primary:hover, .btn-outline-info:hover, .btn-outline-success:hover,
.btn-outline-warning:hover, .btn-outline-danger:hover, .btn-outline-secondary:hover,
.btn-outline-dark:hover {
    color: white !important;
}
@media (max-width: 768px) {
    .service-card { padding: 1.5rem; }
    .service-card h5 { font-size: 1.25rem; }
    .service-card p { font-size: 0.9rem; }
}
</style>
    <section class="py-5 bg-white" id="news">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end mb-4 gap-3">
            <div>
                <h2 class="display-6 fw-bold text-primary mb-2" data-aos="fade-up">
                    <i class="fas fa-newspaper me-2"></i>Latest News & Updates
                </h2>
            </div>
            <a href="all-news.php" class="btn btn-outline-primary" data-aos="fade-up">View All News</a>
        </div>

                    <div class="row g-4">
                                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="0">
                    <article class="home-news-card h-100">
                        <a href="news-detail.php?slug=islamabad-police-continues-measures-for-officer-welfare-prompt-resolution-of-issues-and-improved-facilities" class="home-news-image-link">
                            <img src="assets/images/news/news-a7ac09a9743cbb1e.jpg"
                                 alt="Islamabad Police Continues Measures for Officer Welfare, Prompt Resolution of Issues and Improved Facilities"
                                 class="home-news-image">
                        </a>
                        <div class="home-news-body">
                            <p class="home-news-date mb-2">
                                <i class="far fa-calendar-alt me-2"></i>
                                06 Oct 2026                            </p>
                            <h3 class="home-news-title">
                                <a href="news-detail.php?slug=islamabad-police-continues-measures-for-officer-welfare-prompt-resolution-of-issues-and-improved-facilities">
                                    Islamabad Police Continues Measures for Officer Welfare, Prompt Resolution of Issues and Improved Facilities                                </a>
                            </h3>
                            <a href="news-detail.php?slug=islamabad-police-continues-measures-for-officer-welfare-prompt-resolution-of-issues-and-improved-facilities" class="home-news-read">
                                Read More <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </article>
                </div>
                                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <article class="home-news-card h-100">
                        <a href="news-detail.php?slug=islamabad-police-committed-to-prompt-resolution-of-citizens-issues-and-reuniting-missing-children-with-their-families" class="home-news-image-link">
                            <img src="assets/images/news/news-48f2a62983a1f440.jpg"
                                 alt="Islamabad Police Committed to Prompt Resolution of Citizens’ Issues and Reuniting Missing Children with Their Families"
                                 class="home-news-image">
                        </a>
                        <div class="home-news-body">
                            <p class="home-news-date mb-2">
                                <i class="far fa-calendar-alt me-2"></i>
                                06 Oct 2026                            </p>
                            <h3 class="home-news-title">
                                <a href="news-detail.php?slug=islamabad-police-committed-to-prompt-resolution-of-citizens-issues-and-reuniting-missing-children-with-their-families">
                                    Islamabad Police Committed to Prompt Resolution of Citizens’ Issues and Reuniting Missing Children with Their Families                                </a>
                            </h3>
                            <a href="news-detail.php?slug=islamabad-police-committed-to-prompt-resolution-of-citizens-issues-and-reuniting-missing-children-with-their-families" class="home-news-read">
                                Read More <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </article>
                </div>
                                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
                    <article class="home-news-card h-100">
                        <a href="news-detail.php?slug=igp-islamabad-visits-sumbal-police-station-reviews-security-arrangements-facilities-and-service-delivery" class="home-news-image-link">
                            <img src="assets/images/news/news-f1106377334c8398.jpg"
                                 alt="IGP Islamabad Visits Sumbal Police Station; Reviews Security Arrangements, Facilities and Service Delivery"
                                 class="home-news-image">
                        </a>
                        <div class="home-news-body">
                            <p class="home-news-date mb-2">
                                <i class="far fa-calendar-alt me-2"></i>
                                06 Oct 2026                            </p>
                            <h3 class="home-news-title">
                                <a href="news-detail.php?slug=igp-islamabad-visits-sumbal-police-station-reviews-security-arrangements-facilities-and-service-delivery">
                                    IGP Islamabad Visits Sumbal Police Station; Reviews Security Arrangements, Facilities and Service Delivery                                </a>
                            </h3>
                            <a href="news-detail.php?slug=igp-islamabad-visits-sumbal-police-station-reviews-security-arrangements-facilities-and-service-delivery" class="home-news-read">
                                Read More <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </article>
                </div>
                            </div>
            </div>
</section>

<style>
.home-news-card {
    background: #fff;
    border-radius: 18px;
    overflow: hidden;
    box-shadow: 0 12px 32px rgba(0, 0, 0, 0.08);
    transition: transform 0.35s ease, box-shadow 0.35s ease;
}
.home-news-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 45px rgba(0, 48, 135, 0.15);
}
.home-news-image-link {
    display: block;
}
.home-news-image {
    width: 100%;
    height: 210px;
    object-fit: cover;
}
.home-news-body {
    padding: 1.25rem 1.35rem 1.5rem;
}
.home-news-date {
    color: #6c757d;
    font-size: 0.9rem;
    margin: 0;
}
.home-news-title {
    font-size: 1.05rem;
    font-weight: 700;
    line-height: 1.45;
    margin-bottom: 1rem;
}
.home-news-title a {
    color: #003087;
    text-decoration: none;
}
.home-news-title a:hover {
    color: #0056b3;
}
.home-news-read {
    color: #D4AF37;
    font-weight: 600;
    text-decoration: none;
}
.home-news-read:hover {
    color: #003087;
}
</style>
    <section class="py-5 bg-light" id="initiatives">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="display-6 fw-bold text-primary mb-2" data-aos="fade-up">
                <i class="fas fa-hands-helping me-2"></i>Public Service Initiatives
            </h2>
        </div>

                    <div class="row g-4">
                                                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="0">
                    <a href="initiatives.php?slug=-ssential-afety-ips-for-itizens" class="home-initiative-card text-decoration-none h-100 d-block">
                        <img src="assets/images/initiative-69521c69a7f22.jpeg"
                             alt="Essential Safety Tips for Citizens"
                             class="home-initiative-image">
                        <div class="home-initiative-body">
                            <h3 class="home-initiative-title">Essential Safety Tips for Citizens</h3>
                            <span class="home-initiative-link">Learn more <i class="fas fa-arrow-right ms-1"></i></span>
                        </div>
                    </a>
                </div>
                                                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="80">
                    <a href="initiatives.php?slug=-mergency-elplines" class="home-initiative-card text-decoration-none h-100 d-block">
                        <img src="assets/images/initiative-69521926d9139.jpeg"
                             alt="Emergency Helplines"
                             class="home-initiative-image">
                        <div class="home-initiative-body">
                            <h3 class="home-initiative-title">Emergency Helplines</h3>
                            <span class="home-initiative-link">Learn more <i class="fas fa-arrow-right ms-1"></i></span>
                        </div>
                    </a>
                </div>
                                                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="160">
                    <a href="initiatives.php?slug=-olice-tation-n-heels" class="home-initiative-card text-decoration-none h-100 d-block">
                        <img src="assets/images/initiative-69521ff675054.png"
                             alt="Police Station (PS) On Wheels"
                             class="home-initiative-image">
                        <div class="home-initiative-body">
                            <h3 class="home-initiative-title">Police Station (PS) On Wheels</h3>
                            <span class="home-initiative-link">Learn more <i class="fas fa-arrow-right ms-1"></i></span>
                        </div>
                    </a>
                </div>
                                                <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="240">
                    <a href="initiatives.php?slug=-acilitation-on-wheels" class="home-initiative-card text-decoration-none h-100 d-block">
                        <img src="assets/images/initiative-69521df585e02.jpg"
                             alt="Facilitation on wheels"
                             class="home-initiative-image">
                        <div class="home-initiative-body">
                            <h3 class="home-initiative-title">Facilitation on wheels</h3>
                            <span class="home-initiative-link">Learn more <i class="fas fa-arrow-right ms-1"></i></span>
                        </div>
                    </a>
                </div>
                            </div>
            </div>
</section>

<style>
.home-initiative-card {
    background: #fff;
    border-radius: 18px;
    overflow: hidden;
    box-shadow: 0 10px 28px rgba(0, 0, 0, 0.08);
    transition: transform 0.35s ease, box-shadow 0.35s ease;
    color: inherit;
}
.home-initiative-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 18px 40px rgba(0, 48, 135, 0.14);
}
.home-initiative-image {
    width: 100%;
    height: 170px;
    object-fit: cover;
}
.home-initiative-body {
    padding: 1.15rem 1.25rem 1.35rem;
}
.home-initiative-title {
    font-size: 1rem;
    font-weight: 700;
    color: #003087;
    margin-bottom: 0.85rem;
}
.home-initiative-link {
    color: #D4AF37;
    font-weight: 600;
    font-size: 0.92rem;
}
</style>
    <!-- Mobile Apps Section - FULLY DYNAMIC -->
<section class="py-5 section-apps" id="mobile-apps">
    <div class="container">
        <h2 class="text-center display-5 fw-bold mb-5 text-primary" data-aos="fade-up">
            <i class="fas fa-mobile-alt me-2"></i>Mobile Apps – Download & Stay Safe
        </h2>

        <div class="row g-4 justify-content-center">
                        <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
                <div class="card app-card text-center p-3 h-100 shadow-lg border-0 hover-lift">
                    <img src="assets/images/apps/ictp.png" 
                         alt="Smart ICTP App" 
                         class="app-card-image rounded shadow">
                         <br>
                    <h5 class="fw-bold mb-3">
                        <i class="fas fa-download me-2 text-primary"></i>
                        Smart ICTP App                    </h5>
                    <p class="small text-muted mb-4">Complaints/Verifications/FIR</p>
                    
                    <div class="d-grid gap-2">
                                                    <a href="https://play.google.com/store/apps/details?id=pk.pitb.gov.ictp" target="_blank" class="btn btn-outline-success">
                                <i class="fab fa-google-play me-2"></i>Google Play
                            </a>
                                                                            <a href="https://apps.apple.com/app/id1602517231" target="_blank" class="btn btn-outline-dark">
                                <i class="fab fa-app-store-ios me-2"></i>App Store
                            </a>
                                                                    </div>
                </div>
            </div>
                        <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="400">
                <div class="card app-card text-center p-3 h-100 shadow-lg border-0 hover-lift">
                    <img src="assets/images/apps/1info.png" 
                         alt="1INFO App" 
                         class="app-card-image rounded shadow">
                         <br>
                    <h5 class="fw-bold mb-3">
                        <i class="fas fa-download me-2 text-primary"></i>
                        1INFO App                    </h5>
                    <p class="small text-muted mb-4">Panic Button/Location Share and Information Sharing</p>
                    
                    <div class="d-grid gap-2">
                                                    <a href="https://play.google.com/store/apps/details?id=com.ibex.sos" target="_blank" class="btn btn-outline-success">
                                <i class="fab fa-google-play me-2"></i>Google Play
                            </a>
                                                                            <a href="https://apps.apple.com/my/app/1info/id6477825126" target="_blank" class="btn btn-outline-dark">
                                <i class="fab fa-app-store-ios me-2"></i>App Store
                            </a>
                                                                    </div>
                </div>
            </div>
                        <div class="col-12 col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="600">
                <div class="card app-card text-center p-3 h-100 shadow-lg border-0 hover-lift">
                    <img src="assets/images/apps/tvs.png" 
                         alt="Taxi Verification App" 
                         class="app-card-image rounded shadow">
                         <br>
                    <h5 class="fw-bold mb-3">
                        <i class="fas fa-download me-2 text-primary"></i>
                        Taxi Verification App                    </h5>
                    <p class="small text-muted mb-4">Online Taxi Verification System</p>
                    
                    <div class="d-grid gap-2">
                                                    <a href="https://play.google.com/store/apps/details?id=com.ictp.tvs" target="_blank" class="btn btn-outline-success">
                                <i class="fab fa-google-play me-2"></i>Google Play
                            </a>
                                                                                            </div>
                </div>
            </div>
                    </div>
    </div>
</section>

<style>
.section-apps {
    background: linear-gradient(135deg, #f0f8ff, #e6f3ff);
}
.app-card {
    transition: all 0.4s ease;
    background: white;
    border-radius: 20px;
}
.app-card-image {
    width: 100%;
    height: 280px;
    object-fit: contain;
    margin-bottom: 1rem;
}
.app-card:hover {
    transform: translateY(-15px);
    box-shadow: 0 25px 50px rgba(0,0,0,0.15) !important;
}
.hover-lift { transition: all 0.4s ease; }
@media (max-width: 767.98px) {
    .app-card-image {
        height: 220px;
    }
}
</style>    <!-- ICT Police Divisions showcase — dynamic from `divisions` table -->
<section class="py-5 division-showcase" id="divisions">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <h2 class="display-5 fw-bold text-primary mb-2">
                <i class="fas fa-sitemap me-2"></i>ICT Police Divisions &amp; Branches
            </h2>
            <p class="lead text-muted mb-0">Explore the specialized formations that keep the federal capital safe.</p>
        </div>

        
                    <div class="row g-4">
                                <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
                    <a href="division.php?slug=operations-division"
                       class="division-tile text-decoration-none h-100 d-block">
                        <div class="division-tile-card">
                            <div class="division-tile-media">
                                <img src="assets/images/divisions/ops.png"
                                     alt="Operations"
                                     loading="lazy">
                            </div>
                            <div class="division-tile-body">
                                <h5>Operations</h5>
                                <span class="division-tile-cta">View details <i class="fas fa-arrow-right ms-1"></i></span>
                            </div>
                        </div>
                    </a>
                </div>
                                <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
                    <a href="division.php?slug=security-division"
                       class="division-tile text-decoration-none h-100 d-block">
                        <div class="division-tile-card">
                            <div class="division-tile-media">
                                <img src="assets/images/divisions/sec.png"
                                     alt="Security"
                                     loading="lazy">
                            </div>
                            <div class="division-tile-body">
                                <h5>Security</h5>
                                <span class="division-tile-cta">View details <i class="fas fa-arrow-right ms-1"></i></span>
                            </div>
                        </div>
                    </a>
                </div>
                                <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="160">
                    <a href="division.php?slug=safe-city-islamabad"
                       class="division-tile text-decoration-none h-100 d-block">
                        <div class="division-tile-card">
                            <div class="division-tile-media">
                                <img src="assets/images/divisions/sc.jpg"
                                     alt="Safe City"
                                     loading="lazy">
                            </div>
                            <div class="division-tile-body">
                                <h5>Safe City</h5>
                                <span class="division-tile-cta">View details <i class="fas fa-arrow-right ms-1"></i></span>
                            </div>
                        </div>
                    </a>
                </div>
                                <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="240">
                    <a href="division.php?slug=law-order-and-training-division"
                       class="division-tile text-decoration-none h-100 d-block">
                        <div class="division-tile-card">
                            <div class="division-tile-media">
                                <img src="assets/images/divisions/lo.jpg"
                                     alt="Law &amp; Order"
                                     loading="lazy">
                            </div>
                            <div class="division-tile-body">
                                <h5>Law &amp; Order</h5>
                                <span class="division-tile-cta">View details <i class="fas fa-arrow-right ms-1"></i></span>
                            </div>
                        </div>
                    </a>
                </div>
                                <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="0">
                    <a href="division.php?slug=headquarters-logistics-division"
                       class="division-tile text-decoration-none h-100 d-block">
                        <div class="division-tile-card">
                            <div class="division-tile-media">
                                <img src="assets/images/divisions/hq.jpg"
                                     alt="Headquarters"
                                     loading="lazy">
                            </div>
                            <div class="division-tile-body">
                                <h5>Headquarters</h5>
                                <span class="division-tile-cta">View details <i class="fas fa-arrow-right ms-1"></i></span>
                            </div>
                        </div>
                    </a>
                </div>
                                <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="80">
                    <a href="division.php?slug=special-branch"
                       class="division-tile text-decoration-none h-100 d-block">
                        <div class="division-tile-card">
                            <div class="division-tile-media">
                                <img src="assets/images/divisions/sb.jpg"
                                     alt="Special Branch"
                                     loading="lazy">
                            </div>
                            <div class="division-tile-body">
                                <h5>Special Branch</h5>
                                <span class="division-tile-cta">View details <i class="fas fa-arrow-right ms-1"></i></span>
                            </div>
                        </div>
                    </a>
                </div>
                                <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="160">
                    <a href="division.php?slug=ctd"
                       class="division-tile text-decoration-none h-100 d-block">
                        <div class="division-tile-card">
                            <div class="division-tile-media">
                                <img src="assets/images/divisions/ctd.jpg"
                                     alt="CTD"
                                     loading="lazy">
                            </div>
                            <div class="division-tile-body">
                                <h5>CTD</h5>
                                <span class="division-tile-cta">View details <i class="fas fa-arrow-right ms-1"></i></span>
                            </div>
                        </div>
                    </a>
                </div>
                                <div class="col-6 col-md-4 col-lg-3" data-aos="fade-up" data-aos-delay="240">
                    <a href="division.php?slug=islamabad-traffic-police"
                       class="division-tile text-decoration-none h-100 d-block">
                        <div class="division-tile-card">
                            <div class="division-tile-media">
                                <img src="assets/images/divisions/itp.jpg"
                                     alt="ITP"
                                     loading="lazy">
                            </div>
                            <div class="division-tile-body">
                                <h5>ITP</h5>
                                <span class="division-tile-cta">View details <i class="fas fa-arrow-right ms-1"></i></span>
                            </div>
                        </div>
                    </a>
                </div>
                            </div>
            </div>
</section>

<style>
.division-showcase {
    background: linear-gradient(180deg, #f8fafc 0%, #eef3f9 100%);
}
.division-tile-card {
    background: #fff;
    border-radius: 18px;
    overflow: hidden;
    height: 100%;
    border: 1px solid rgba(12, 49, 93, 0.08);
    box-shadow: 0 12px 30px rgba(12, 49, 93, 0.07);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.division-tile:hover .division-tile-card {
    transform: translateY(-8px);
    box-shadow: 0 20px 42px rgba(12, 49, 93, 0.14);
}
.division-tile-media {
    height: 150px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(145deg, #f4f7fb, #e8eef6);
    border-bottom: 1px solid #e8eef6;
    padding: 1rem;
}
.division-tile-media img {
    max-height: 100%;
    max-width: 100%;
    object-fit: contain;
    transition: transform 0.35s ease;
}
.division-tile:hover .division-tile-media img {
    transform: scale(1.08);
}
.division-tile-body {
    padding: 1rem 1rem 1.15rem;
    text-align: center;
}
.division-tile-body h5 {
    margin: 0 0 0.4rem;
    color: #0c315d;
    font-weight: 750;
    font-size: 1.02rem;
    line-height: 1.3;
}
.division-tile-cta {
    color: #b8860b;
    font-size: 0.85rem;
    font-weight: 650;
}
.division-tile:hover .division-tile-cta {
    color: #d4af37;
}
@media (max-width: 575.98px) {
    .division-tile-media { height: 120px; }
    .division-tile-body h5 { font-size: 0.92rem; }
}
</style>
    <section class="py-5" id="notices">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-end mb-4 gap-3">
            <div>
                <h2 class="display-6 fw-bold text-primary mb-2" data-aos="fade-up">
                    <i class="fas fa-briefcase me-2"></i>Jobs, Tenders & Auctions
                </h2>
            </div>
            <a href="notices.php" class="btn btn-outline-primary" data-aos="fade-up">View All</a>
        </div>

                    <div class="row g-4">
                                                <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="0">
                    <article class="home-notice-box h-100">
                        <div class="home-notice-box-top">
                            <span class="home-notice-box-badge home-notice-box-badge-job">
                                Job                            </span>
                            <span class="home-notice-box-date">
                                <i class="far fa-calendar-alt me-1"></i>
                                19 Aug 2026                            </span>
                        </div>
                        <h3 class="home-notice-box-title">
                            <a href="notice-detail.php?type=job&amp;id=6">
                                Islamabad Police Jobs Openings                            </a>
                        </h3>
                        <div class="home-notice-box-actions mt-auto">
                            <a href="notice-detail.php?type=job&amp;id=6" class="btn btn-sm btn-outline-primary">
                                View Details
                            </a>
                                                        <a href="notices/notice_6a85581d60e915.00979285.pdf"
                               target="_blank" rel="noopener"
                               class="btn btn-sm btn-primary">
                                <i class="fas fa-download me-1"></i>PDF
                            </a>
                                                    </div>
                    </article>
                </div>
                            </div>
            </div>
</section>

<style>
#notices {
    background: linear-gradient(180deg, #f8fbff 0%, #ffffff 100%);
}
.home-notices-empty {
    background: #fff;
    border-radius: 18px;
    border: 1px dashed #d7e3f0;
}
.home-notice-box {
    display: flex;
    flex-direction: column;
    background: #fff;
    border: 1px solid #e8eef5;
    border-radius: 18px;
    padding: 1.35rem 1.4rem 1.4rem;
    box-shadow: 0 10px 28px rgba(0, 0, 0, 0.06);
    transition: transform 0.35s ease, box-shadow 0.35s ease, border-color 0.35s ease;
    min-height: 220px;
}
.home-notice-box:hover {
    transform: translateY(-8px);
    box-shadow: 0 18px 40px rgba(0, 48, 135, 0.12);
    border-color: #c9d9ee;
}
.home-notice-box-top {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: center;
    gap: 0.65rem;
    margin-bottom: 1rem;
}
.home-notice-box-badge {
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.4px;
    text-transform: uppercase;
    padding: 0.3rem 0.7rem;
    border-radius: 999px;
    color: #fff;
}
.home-notice-box-badge-job { background: #0d6efd; }
.home-notice-box-badge-tender { background: #003087; }
.home-notice-box-badge-auction { background: #b8860b; }
.home-notice-box-badge-transfer,
.home-notice-box-badge-order {
    background: #495057;
}
.home-notice-box-date {
    color: #6c757d;
    font-size: 0.88rem;
}
.home-notice-box-title {
    font-size: 1.05rem;
    font-weight: 700;
    line-height: 1.45;
    margin-bottom: 1.25rem;
    flex-grow: 1;
}
.home-notice-box-title a {
    color: #003087;
    text-decoration: none;
}
.home-notice-box-title a:hover {
    color: #0056b3;
}
.home-notice-box-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
}
</style>
    <section class="py-5 bg-primary text-white" id="connect">
    <div class="container">
        <div class="row g-4 align-items-stretch">
            <div class="col-lg-5" data-aos="fade-right">
                <div class="home-connect-radio h-100">
                    <p class="text-uppercase small fw-bold mb-2 opacity-75">Public Relations</p>
                    <h2 class="fw-bold mb-3">
                        <i class="fas fa-broadcast-tower me-2 text-warning"></i>
                        Islamabad Police FM 92.4
                    </h2>
                    <a href="https://icpfm.radiostream321.com/" target="_blank" rel="noopener"
                       class="btn btn-warning btn-lg fw-bold">
                        <i class="fas fa-play-circle me-2"></i>Listen Live
                    </a>
                </div>
            </div>
            <div class="col-lg-7" data-aos="fade-left">
                <div class="home-connect-social h-100">
                    <h2 class="fw-bold mb-3">
                        <i class="fas fa-share-alt me-2 text-warning"></i>Stay Connected
                    </h2>
                    <div class="row g-3">
                        <div class="col-sm-6">
                            <a href="https://www.facebook.com/islamabadpolice" target="_blank" rel="noopener" class="social-tile">
                                <i class="fab fa-facebook-f"></i>
                                <span>Facebook</span>
                            </a>
                        </div>
                        <div class="col-sm-6">
                            <a href="https://twitter.com/ICT_Police" target="_blank" rel="noopener" class="social-tile">
                                <i class="fab fa-x-twitter"></i>
                                <span>X (Twitter)</span>
                            </a>
                        </div>
                        <div class="col-sm-6">
                            <a href="https://www.instagram.com/islamabadpolice/" target="_blank" rel="noopener" class="social-tile">
                                <i class="fab fa-instagram"></i>
                                <span>Instagram</span>
                            </a>
                        </div>
                        <div class="col-sm-6">
                            <a href="https://www.youtube.com/c/IslamabadPolice1" target="_blank" rel="noopener" class="social-tile">
                                <i class="fab fa-youtube"></i>
                                <span>YouTube</span>
                            </a>
                        </div>
                    </div>
                    <div class="mt-4">
                        <a href="media.php" class="btn btn-outline-light">Visit Media Center</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
#connect {
    background: linear-gradient(135deg, #003087 0%, #0056b3 100%) !important;
}
.home-connect-radio,
.home-connect-social {
    background: rgba(255, 255, 255, 0.08);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 18px;
    padding: 1.75rem;
}
.social-tile {
    display: flex;
    align-items: center;
    gap: 0.85rem;
    padding: 0.95rem 1.1rem;
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.12);
    color: #fff;
    text-decoration: none;
    font-weight: 600;
    transition: background 0.3s ease, transform 0.3s ease;
}
.social-tile i {
    font-size: 1.35rem;
    width: 28px;
    text-align: center;
}
.social-tile:hover {
    background: rgba(255, 255, 255, 0.22);
    transform: translateY(-3px);
    color: #fff;
}
</style>
    <!-- Find Nearest Police Station & PKM – Interactive Map -->
<section class="py-5 section-locator bg-light" id="locator">
    <div class="container">
        <h2 class="text-center display-5 fw-bold mb-5 text-primary" data-aos="fade-up">
            <i class="fas fa-search-location me-2"></i>Find Nearest Police Station & PKM – Interactive Map
        </h2>

        <div class="row mb-4 text-center g-3">
             <div class="col-6 col-md-3">
               <button class="btn btn-danger btn-lg w-100 w-md-auto" onclick="getCurrentLocation()">
                        <i class="fas fa-location-arrow me-2"></i>FIND NEAR ME
                    </button>
            </div>
            <div class="col-6 col-md-3">
                <button class="btn btn-primary btn-lg w-100" onclick="filterMarkers('PS')">
                    <i class="fas fa-shield-alt me-2"></i>Police Stations
                </button>
            </div>
            <div class="col-6 col-md-3">
                <button class="btn btn-success btn-lg w-100" onclick="filterMarkers('PKM')">
                    <i class="fas fa-handshake me-2"></i>PKM Centers
                </button>
            </div>
            <div class="col-6 col-md-3">
                <button class="btn btn-info btn-lg w-100" onclick="filterMarkers('Office')">
                    <i class="fas fa-building me-2"></i>Police Offices
                </button>
            </div>
        </div>

        <div id="map" class="map-container rounded-4 shadow-lg"></div>
        <div class="map-legend" aria-label="Map legend">
            <span class="map-legend-item"><i class="fas fa-shield fa-lg text-danger"></i> Police Station</span>
            <span class="map-legend-item"><i class="fas fa-handshake fa-lg text-success"></i> PKM Center</span>
            <span class="map-legend-item"><i class="fas fa-building fa-lg text-primary"></i> Police Office</span>
        </div>
        <div id="results" class="mt-4"></div>
        <div id="map-billing-note" class="alert alert-warning mt-3 mb-0 d-none" role="status"></div>
    </div>
</section>

<style>
.section-locator { background: linear-gradient(to bottom, #f8f9fa, #e9ecef); }
.map-container {
    height: 650px;
    border-radius: 24px;
    box-shadow: 0 15px 40px rgba(0,0,0,0.15);
    transition: all 0.4s ease;
}
.map-container:hover {
    box-shadow: 0 25px 60px rgba(0,0,0,0.2);
}
.popup-content {
    min-width: 280px;
    font-family: 'Inter', sans-serif;
}
.popup-content h5 {
    color: #003087;
    border-bottom: 2px solid #D4AF37;
    padding-bottom: 8px;
    margin-bottom: 12px;
}
.popup-content p {
    margin-bottom: 8px;
    font-size: 0.95rem;
}
.popup-content a.btn {
    background: #003087;
    color: white;
    font-weight: 600;
}
.popup-content a.btn:hover {
    background: #D4AF37;
    color: black;
}
#results .card {
    border-radius: 15px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.1);
    transition: transform 0.3s ease;
}
#results .card:hover {
    transform: translateY(-8px);
}
/* Same visual as previous Leaflet custom-icon markers */
.custom-icon,
.gmap-fa-marker {
    background: transparent !important;
    border: none !important;
    box-shadow: none !important;
}
.gmap-fa-marker {
    position: absolute;
    transform: translate(-50%, -100%);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 1;
    line-height: 1;
    filter: drop-shadow(0 1px 2px rgba(0, 0, 0, 0.35));
}
.gmap-fa-marker i {
    line-height: 1;
    pointer-events: none;
}
.gmap-fa-marker:hover {
    transform: translate(-50%, -100%) scale(1.12);
    z-index: 5;
}
.map-legend {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem 1.5rem;
    justify-content: center;
    margin-top: 1rem;
    font-size: 0.95rem;
    color: #334155;
}
.map-legend-item {
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
}
.map-legend-item i {
    font-size: 1.15rem;
}
@media (max-width: 768px) {
    .map-container { height: 380px; }
    .section-locator h2 {
        font-size: 1.5rem;
    }
}
</style>

<script>
let map;
let markers = [];
let allLocations = [];
let infoWindow;
let userMarker;
let activeFilter = 'all';
let mapEngine = 'none'; // 'google' | 'leaflet'
let mapReady = false;

function escapeHtml(text) {
    return String(text ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function haversineMeters(lat1, lng1, lat2, lng2) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(lat2 - lat1);
    const dLng = toRad(lng2 - lng1);
    const a = Math.sin(dLat / 2) ** 2
        + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(a));
}

/** Exact same icon HTML previously used on the Leaflet map */
function markerIconHtml(type) {
    if (type === 'PS') {
        return '<i class="fas fa-shield fa-2x text-danger"></i>';
    }
    if (type === 'PKM') {
        return '<i class="fas fa-handshake fa-2x text-success"></i>';
    }
    return '<i class="fas fa-building fa-2x text-primary"></i>';
}

function buildInfoHtml(loc, lat, lng) {
    const servicesLine = loc.type === 'Office'
        ? ''
        : `<p><strong>Services:</strong> ${escapeHtml(loc.services || '—')}</p>`;
    const directions = mapEngine === 'google'
        ? `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`
        : `https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=${lat}%2C${lng}`;
    return `
        <div class="popup-content">
            <h5>${escapeHtml(loc.name)}</h5>
            <p><strong>Hours:</strong> ${escapeHtml(loc.hours || '—')}</p>
            <p><strong>Address:</strong> ${escapeHtml(loc.address)}</p>
            <p><strong>Contact:</strong> ${escapeHtml(loc.contact || 'N/A')}</p>
            ${servicesLine}
            <a href="${directions}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm w-100">
                Get Directions
            </a>
        </div>
    `;
}

function clearMarkers() {
    markers.forEach(m => {
        try {
            if (mapEngine === 'google' && m.marker && m.marker.setMap) {
                m.marker.setMap(null);
            } else if (mapEngine === 'leaflet' && map && m.marker) {
                map.removeLayer(m.marker);
            }
        } catch (e) {}
    });
    markers = [];
}

function createGoogleHtmlMarker(position, type, title) {
    const el = document.createElement('div');
    el.className = 'gmap-fa-marker custom-icon';
    el.title = title || '';
    el.innerHTML = markerIconHtml(type);

    const overlay = new google.maps.OverlayView();
    overlay.position = position;
    overlay.type = type;
    overlay.el = el;
    overlay.visible = true;

    overlay.onAdd = function () {
        const panes = this.getPanes();
        if (panes && panes.overlayMouseTarget) {
            panes.overlayMouseTarget.appendChild(this.el);
        }
    };
    overlay.draw = function () {
        const projection = this.getProjection();
        if (!projection || !this.el) return;
        const point = projection.fromLatLngToDivPixel(
            new google.maps.LatLng(this.position.lat, this.position.lng)
        );
        if (!point) return;
        this.el.style.left = point.x + 'px';
        this.el.style.top = point.y + 'px';
        this.el.style.display = this.visible ? 'flex' : 'none';
    };
    overlay.onRemove = function () {
        if (this.el && this.el.parentNode) {
            this.el.parentNode.removeChild(this.el);
        }
    };
    overlay.setVisible = function (show) {
        this.visible = !!show;
        if (this.el) {
            this.el.style.display = this.visible ? 'flex' : 'none';
        }
    };
    overlay.setMap(map);
    return overlay;
}

function addLocationMarkers(data) {
    allLocations = Array.isArray(data) ? data : [];
    clearMarkers();
    if (!map) return;

    allLocations.forEach(loc => {
        const lat = Number(loc.lat);
        const lng = Number(loc.lng);
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;

        if (mapEngine === 'google') {
            const position = { lat, lng };
            const marker = createGoogleHtmlMarker(position, loc.type, String(loc.name || ''));
            marker.setVisible(activeFilter === 'all' || loc.type === activeFilter);
            marker.el.addEventListener('click', (evt) => {
                evt.stopPropagation();
                if (!infoWindow) infoWindow = new google.maps.InfoWindow();
                infoWindow.setContent(buildInfoHtml(loc, lat, lng));
                infoWindow.setPosition(position);
                infoWindow.open(map);
            });
            markers.push({ marker, type: loc.type, lat, lng });
            return;
        }

        if (mapEngine === 'leaflet' && typeof L !== 'undefined') {
            const icon = L.divIcon({
                className: 'custom-icon',
                html: markerIconHtml(loc.type),
                iconSize: [30, 30],
                iconAnchor: [15, 30]
            });
            const marker = L.marker([lat, lng], { icon })
                .bindTooltip(escapeHtml(String(loc.name || '')), { permanent: false, direction: 'top' })
                .bindPopup(buildInfoHtml(loc, lat, lng));
            if (activeFilter === 'all' || loc.type === activeFilter) {
                marker.addTo(map);
            }
            markers.push({ marker, type: loc.type, lat, lng });
        }
    });
}

function loadLocations() {
    return fetch('api-loc.php', { credentials: 'same-origin' })
        .then(response => {
            if (!response.ok) throw new Error('Locations API error');
            return response.json();
        })
        .then(data => {
            addLocationMarkers(data);
            return data;
        })
        .catch(() => {
            const resultsEl = document.getElementById('results');
            if (resultsEl) {
                resultsEl.innerHTML = '<div class="alert alert-warning">Map locations could not be loaded. Please refresh the page.</div>';
            }
            return [];
        });
}

function dismissGoogleErrorDialog() {
    try {
        document.querySelectorAll('button.dismissButton, .gm-style-iw button, .dismissButton').forEach(btn => {
            if (/ok/i.test(btn.textContent || '')) btn.click();
        });
        // Hide watermarked error chrome if still present
        document.querySelectorAll('.gm-err-container, .gm-style-pbc').forEach(el => {
            el.style.display = 'none';
        });
    } catch (e) {}
}

function showBillingNote() {
    const note = document.getElementById('map-billing-note');
    if (!note) return;
    note.classList.remove('d-none');
    note.innerHTML = 'Google Maps API key needs <strong>billing enabled</strong> in Google Cloud Console. '
        + 'Map is using a temporary backup layer until billing is activated. '
        + '<a href="https://console.cloud.google.com/project/_/billing/enable" target="_blank" rel="noopener">Enable billing</a>';
}

function loadScript(src) {
    return new Promise((resolve, reject) => {
        if ([...document.scripts].some(s => s.src === src)) {
            resolve();
            return;
        }
        const s = document.createElement('script');
        s.src = src;
        s.async = true;
        s.onload = () => resolve();
        s.onerror = reject;
        document.head.appendChild(s);
    });
}

function loadCss(href) {
    if ([...document.querySelectorAll('link')].some(l => l.href === href)) return;
    const l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = href;
    document.head.appendChild(l);
}

function initLeafletFallback() {
    if (mapEngine === 'leaflet' && map) return;
    dismissGoogleErrorDialog();
    showBillingNote();

    const mapEl = document.getElementById('map');
    if (!mapEl) return;

    // Reset container after failed Google paint
    mapEl.innerHTML = '';
    map = null;
    markers = [];
    infoWindow = null;
    userMarker = null;

    loadCss('https://unpkg.com/leaflet@1.9.4/dist/leaflet.css');
    loadScript('https://unpkg.com/leaflet@1.9.4/dist/leaflet.js').then(() => {
        mapEngine = 'leaflet';
        map = L.map('map', { scrollWheelZoom: true, zoomControl: true }).setView([33.6844, 73.0479], 12);
        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
            attribution: 'Tiles &copy; Esri',
            maxZoom: 19
        }).addTo(map);
        mapReady = true;
        loadLocations().then(() => setTimeout(() => map && map.invalidateSize(), 150));
    }).catch(() => {
        const resultsEl = document.getElementById('results');
        if (resultsEl) {
            resultsEl.innerHTML = '<div class="alert alert-danger">Map could not be loaded. Please enable Google Maps billing or try again later.</div>';
        }
    });
}

function initMap() {
    const mapEl = document.getElementById('map');
    if (!mapEl || typeof google === 'undefined' || !google.maps) {
        return;
    }
    if (mapEngine === 'google' && map) {
        google.maps.event.trigger(map, 'resize');
        return;
    }

    try {
        mapEngine = 'google';
        map = new google.maps.Map(mapEl, {
            center: { lat: 33.6844, lng: 73.0479 },
            zoom: 12,
            mapTypeControl: true,
            streetViewControl: false,
            fullscreenControl: true
        });
        infoWindow = new google.maps.InfoWindow();
        mapReady = true;
        loadLocations();

        // If Google still paints the billing error shortly after init, fall back
        setTimeout(() => {
            const broken = /can't load Google Maps correctly|development purposes only/i.test(document.body.innerText || '');
            if (broken && mapEngine === 'google') {
                initLeafletFallback();
            }
        }, 1800);
    } catch (e) {
        initLeafletFallback();
    }
}

window.initMap = initMap;

// Called by Google Maps JS when the API key/auth fails (e.g. billing disabled)
window.gm_authFailure = function () {
    initLeafletFallback();
};

function filterMarkers(type) {
    activeFilter = type || 'all';
    if (!map) return;
    markers.forEach(m => {
        const show = activeFilter === 'all' || m.type === activeFilter;
        if (mapEngine === 'google' && typeof m.marker.setVisible === 'function') {
            m.marker.setVisible(show);
        } else if (mapEngine === 'leaflet') {
            if (show) {
                if (!map.hasLayer(m.marker)) m.marker.addTo(map);
            } else if (map.hasLayer(m.marker)) {
                map.removeLayer(m.marker);
            }
        }
    });
}

function getCurrentLocation() {
    if (!map) {
        if (typeof google !== 'undefined' && google.maps) initMap();
        else initLeafletFallback();
    }
    if (!navigator.geolocation) {
        alert('Geolocation is not supported by this browser.');
        return;
    }
    navigator.geolocation.getCurrentPosition(pos => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;

        if (mapEngine === 'google') {
            const position = { lat, lng };
            map.setCenter(position);
            map.setZoom(15);
            if (userMarker && userMarker.setMap) userMarker.setMap(null);
            userMarker = new google.maps.Marker({
                position,
                map,
                title: 'You are here',
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 8,
                    fillColor: '#0ea5e9',
                    fillOpacity: 0.95,
                    strokeColor: '#003087',
                    strokeWeight: 2
                }
            });
            if (!infoWindow) infoWindow = new google.maps.InfoWindow();
            infoWindow.setContent('You are here');
            infoWindow.open({ map, anchor: userMarker });
        } else if (mapEngine === 'leaflet') {
            map.setView([lat, lng], 15);
            if (userMarker) map.removeLayer(userMarker);
            userMarker = L.circleMarker([lat, lng], {
                radius: 8,
                color: '#003087',
                fillColor: '#0ea5e9',
                fillOpacity: 0.9,
                weight: 2
            }).addTo(map).bindPopup('You are here').openPopup();
        }
        findNearest(lat, lng);
    }, () => alert('Unable to get your location. Please allow location access.'));
}

function focusLocation(lat, lng) {
    if (!map) return;
    if (mapEngine === 'google') {
        map.setCenter({ lat: Number(lat), lng: Number(lng) });
        map.setZoom(16);
    } else if (mapEngine === 'leaflet') {
        map.setView([Number(lat), Number(lng)], 16);
    }
}

function findNearest(userLat, userLng) {
    const source = allLocations.length ? Promise.resolve(allLocations) : loadLocations();
    source.then(data => {
        if (!map || !Array.isArray(data) || !data.length) return;
        const nearest = data.map(loc => {
            const dist = haversineMeters(userLat, userLng, Number(loc.lat), Number(loc.lng));
            return { ...loc, dist };
        }).sort((a, b) => a.dist - b.dist).slice(0, 5);

        let html = '<h4 class="text-center mb-4">Nearest Locations</h4><div class="row g-3">';
        nearest.forEach(n => {
            html += `
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h6>${escapeHtml(n.name)} (${escapeHtml(n.type)})</h6>
                            <p class="small text-muted">${Math.round(n.dist)} meters away</p>
                            <button class="btn btn-sm btn-primary w-100" onclick="focusLocation(${Number(n.lat)}, ${Number(n.lng)})">View on Map</button>
                        </div>
                    </div>
                </div>`;
        });
        html += '</div>';
        const resultsEl = document.getElementById('results');
        if (resultsEl) resultsEl.innerHTML = html;
    });
}
</script>
<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDn7Do3Y0Cc-NL_DUb1FUsowiyOT8RrGJw&callback=initMap">
</script>
    <footer class="bg-dark text-white py-5" id="site-footer">
    <div class="container">
        <div class="row g-4 mb-4">
            <div class="col-lg-4 footer-section">
                <img src="assets/images/Capital_Territory_Police.png" alt="ICT Police" height="72" class="mb-3">
                <h5 class="fw-bold text-gold mb-3">Islamabad Capital Territory Police</h5>
                <p class="small text-white-50 mb-0">
                    Serving citizens with integrity, innovation, and community-focused policing across Islamabad.
                </p>
            </div>

            <div class="col-lg-4 footer-section">
                <h5 class="fw-bold mb-3">Quick Links</h5>
                <ul class="list-unstyled footer-links mb-0">
                                        <li class="mb-2">
                        <a href="index.php#online-services" class="footer-link">
                                                            <i class="fas fa-laptop-house me-2"></i>
                                                        Citizen Services                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="index.php#locator" class="footer-link">
                                                            <i class="fas fa-map-marker-alt me-2"></i>
                                                        Find PS / PKM                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="media.php" class="footer-link">
                                                            <i class="fas fa-newspaper me-2"></i>
                                                        News &amp; Media                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="notices.php" class="footer-link">
                                                            <i class="fas fa-briefcase me-2"></i>
                                                        Jobs, Tenders &amp; Auctions                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="contact.php" class="footer-link">
                                                            <i class="fas fa-headset me-2"></i>
                                                        Contact Us                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="igp-message.php" class="footer-link">
                                                            <i class="fas fa-user-shield me-2"></i>
                                                        IGP Message                        </a>
                    </li>
                                    </ul>
            </div>

            <div class="col-lg-4 footer-section">
                <h5 class="fw-bold mb-3">Emergency Helplines</h5>
                <ul class="list-unstyled footer-helplines mb-4">
                                        <li class="mb-2">
                        <a href="tel:15" class="footer-link">
                            <i class="fas fa-phone-volume me-2 text-gold"></i>
                            <strong>Emergency:</strong>
                            15                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="tel:1715" class="footer-link">
                            <i class="fas fa-phone-alt me-2 text-gold"></i>
                            <strong>IGP Helpline:</strong>
                            1715                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="tel:1815" class="footer-link">
                            <i class="fas fa-users me-2 text-gold"></i>
                            <strong>Online Women Helpline:</strong>
                            1815                        </a>
                    </li>
                                        <li class="mb-2">
                        <a href="tel:1915" class="footer-link">
                            <i class="fas fa-car me-2 text-gold"></i>
                            <strong>ITP Helpline:</strong>
                            1915                        </a>
                    </li>
                                    </ul>
                <div class="footer-social d-flex gap-2 flex-wrap">
                    <a href="https://www.facebook.com/islamabadpolice" target="_blank" rel="noopener" class="social-btn" aria-label="Facebook">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="https://twitter.com/ICT_Police" target="_blank" rel="noopener" class="social-btn" aria-label="X">
                        <i class="fab fa-x-twitter"></i>
                    </a>
                    <a href="https://www.instagram.com/islamabadpolice/" target="_blank" rel="noopener" class="social-btn" aria-label="Instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="https://www.youtube.com/c/IslamabadPolice1" target="_blank" rel="noopener" class="social-btn" aria-label="YouTube">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
        </div>

        <hr class="border-secondary opacity-50">

        <div class="row align-items-center pt-2">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0 small text-white-50">
                    <i class="fas fa-copyright me-2"></i>2026 Islamabad Capital Territory Police. All Rights Reserved.
                </p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <p class="mb-0 small text-white-50">
                    Developed by <strong class="text-gold">Safe City Islamabad</strong>
                </p>
            </div>
        </div>
    </div>
</footer>

<style>
.bg-dark {
    background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%) !important;
}
.text-gold { color: #D4AF37 !important; }
.footer-link {
    color: rgba(255, 255, 255, 0.82);
    text-decoration: none;
    font-size: 0.95rem;
    transition: color 0.2s ease;
}
.footer-link:hover { color: #D4AF37; }
.social-btn {
    width: 42px;
    height: 42px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 0.1);
    color: #fff;
    text-decoration: none;
    transition: background 0.2s ease, transform 0.2s ease;
}
.social-btn:hover {
    background: #D4AF37;
    color: #0f172a;
    transform: translateY(-2px);
}
@media (max-width: 992px) {
    .footer-section h5 { text-align: center; }
}
@media (max-width: 576px) {
    .footer-section { text-align: center; }
    .footer-social { justify-content: center; }
}
</style>

    
<a href="https://wa.me/923326001069?text=Hello%2C%20I%20would%20like%20to%20chat%20with%20ICT%20Police."
   class="ict-whatsapp-float"
   id="ictWhatsAppFloat"
   target="_blank"
   rel="noopener noreferrer"
   aria-label="Chat on WhatsApp — +92 332 6001069">
    <span class="ict-whatsapp-float__pulse" aria-hidden="true"></span>
    <i class="fab fa-whatsapp" aria-hidden="true"></i>
    <span class="ict-whatsapp-float__label">Live Chat</span>
</a>

<style>
.ict-whatsapp-float {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 9999;
    display: inline-flex;
    align-items: center;
    gap: 0.65rem;
    padding: 0.85rem 1.15rem 0.85rem 0.95rem;
    border-radius: 999px;
    background: linear-gradient(135deg, #25d366 0%, #128c7e 100%);
    color: #fff !important;
    text-decoration: none;
    font-weight: 600;
    font-size: 0.95rem;
    line-height: 1;
    box-shadow:
        0 8px 24px rgba(37, 211, 102, 0.45),
        0 2px 8px rgba(0, 0, 0, 0.15);
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
}

.ict-whatsapp-float:hover {
    transform: translateY(-3px) scale(1.02);
    color: #fff !important;
    box-shadow:
        0 12px 28px rgba(37, 211, 102, 0.5),
        0 4px 12px rgba(0, 0, 0, 0.18);
}

.ict-whatsapp-float:focus-visible {
    outline: 3px solid #d4af37;
    outline-offset: 3px;
}

.ict-whatsapp-float i {
    font-size: 1.65rem;
}

.ict-whatsapp-float__label {
    letter-spacing: 0.02em;
}

.ict-whatsapp-float__pulse {
    position: absolute;
    inset: 0;
    border-radius: 999px;
    background: rgba(37, 211, 102, 0.35);
    animation: ict-whatsapp-pulse 2.2s ease-out infinite;
    pointer-events: none;
}

@keyframes ict-whatsapp-pulse {
    0% {
        transform: scale(1);
        opacity: 0.7;
    }
    70% {
        transform: scale(1.35);
        opacity: 0;
    }
    100% {
        transform: scale(1.35);
        opacity: 0;
    }
}

@media (max-width: 575.98px) {
    .ict-whatsapp-float {
        padding: 0.75rem;
        border-radius: 50%;
        width: 56px;
        height: 56px;
        justify-content: center;
    }

    .ict-whatsapp-float__label {
        display: none;
    }

    .ict-whatsapp-float i {
        font-size: 1.75rem;
    }
}
</style>

<script>
(function () {
    var btn = document.getElementById('ictWhatsAppFloat');
    if (!btn) {
        return;
    }

    function isMobileView() {
        return window.matchMedia('(max-width: 575.98px)').matches;
    }

    function resetDesktopPosition() {
        btn.style.removeProperty('left');
        btn.style.removeProperty('top');
        btn.style.removeProperty('right');
        btn.style.removeProperty('bottom');
    }

    function pinWhatsApp() {
        if (!isMobileView() || !window.visualViewport) {
            resetDesktopPosition();
            return;
        }

        var vv = window.visualViewport;
        var margin = 16;
        var w = btn.offsetWidth || 56;
        var h = btn.offsetHeight || 56;
        var left = vv.offsetLeft + vv.width - w - margin;
        var top = vv.offsetTop + vv.height - h - margin;

        btn.style.setProperty('left', Math.round(left) + 'px', 'important');
        btn.style.setProperty('top', Math.round(top) + 'px', 'important');
        btn.style.setProperty('right', 'auto', 'important');
        btn.style.setProperty('bottom', 'auto', 'important');
    }

    window.ictPinWhatsApp = pinWhatsApp;

    if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', pinWhatsApp, { passive: true });
        window.visualViewport.addEventListener('scroll', pinWhatsApp, { passive: true });
    }
    window.addEventListener('resize', pinWhatsApp, { passive: true });
    window.addEventListener('orientationchange', pinWhatsApp, { passive: true });
    window.addEventListener('scroll', pinWhatsApp, { passive: true });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', pinWhatsApp);
    } else {
        pinWhatsApp();
    }
})();
</script>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({ duration: 1000, once: true });

        function animateHeroContent(slide) {
            if (!slide) return;
            const content = slide.querySelector('.hero-content');
            if (!content) return;
            content.classList.remove('is-visible');
            void content.offsetWidth;
            content.classList.add('is-visible');
        }

        const heroSliderEl = document.querySelector('.hero-slider');
        if (heroSliderEl) {
            new Swiper('.hero-slider', {
                loop: true,
                autoplay: { delay: 4000 },
                pagination: { el: '.swiper-pagination', clickable: true },
                speed: 700,
                on: {
                    init(swiper) {
                        animateHeroContent(swiper.slides[swiper.activeIndex]);
                    },
                    slideChangeTransitionStart(swiper) {
                        swiper.slides.forEach(slide => {
                            const content = slide.querySelector('.hero-content');
                            if (content) content.classList.remove('is-visible');
                        });
                    },
                    slideChangeTransitionEnd(swiper) {
                        animateHeroContent(swiper.slides[swiper.activeIndex]);
                    },
                },
            });
        }

        const navbar = document.querySelector('.navbar');
        if (navbar) {
            window.addEventListener('scroll', () => {
                navbar.classList.toggle('sticky', window.scrollY > 0);
            }, { passive: true });
        }
    </script>
</body>
</html>
